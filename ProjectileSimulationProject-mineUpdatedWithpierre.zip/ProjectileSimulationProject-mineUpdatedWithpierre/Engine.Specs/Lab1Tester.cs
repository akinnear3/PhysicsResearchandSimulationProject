﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Classes;
using Xunit;

namespace Engine.Specs
{
    public class Lab1Tester
    {
        // calling a method that returns a Tuple<>
        // Tuple<double, double> results = Calculator.SomeMethodName(val1, val2);

        // returning Tuple values from a method
        // return new Tuple<double, double>(returnVal1, returnVal2);


        #region Trigonometry_Tests
        [Theory]
        // Instructor Data
        [InlineData(25, 6, 5.4378, 2.5357)]
        // Student Data
        [InlineData(10, 10, 9.8481, 1.7365)]
        public void TestCalculateAdjacentOpposite(double Angle, double Hypotenuse, double Adjacent, double Opposite)
        {
            // Act
            Tuple<double, double> results = Calculator.Trig_Calculate_Adjacent_Opposite(Angle, Hypotenuse);

            // Assert
            Assert.Equal(Adjacent, Math.Round(results.Item1, 4));
            Assert.Equal(Opposite, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(25, 6, 12.867, 14.1972)]
        // Student Data
        [InlineData(10, 10, 56.7128, 57.5877)]
        public void TestCalculateAdjacentHypotenuse(double Angle, double Opposite, double Adjacent, double Hypotenuse)
        {
            // Act - performing the action
            Tuple<double, double> results = Calculator.Trig_Calculate_Adjacent_Hypotenuse(Angle, Opposite);
            // Assert - did we get back the correct answer
            Assert.Equal(Adjacent, Math.Round(results.Item1, 4));
            Assert.Equal(Hypotenuse, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(25, 6, 2.7978, 6.6203)]
        // Student Data
        [InlineData(10, 10, 1.7633, 10.1543)]
        public void TestCalculateOppositeHypotenuse(double Angle, double Adjacent, double Opposite, double Hypotenuse)
        {
            // Act - performing the action
            Tuple<double, double> results = Calculator.Trig_Calculate_Opposite_Hypotenuse(Angle, Adjacent);
            // Assert - did we get back the correct answer
            Assert.Equal(Opposite, Math.Round(results.Item1, 4));
            Assert.Equal(Hypotenuse, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 5, 53.1301)]
        // Student Data
        [InlineData(10, 10, 14.1421, 45)]
        public void TestCalculateHypotenuseTheta(double Adjacent, double Opposite, double Hypotenuse, double Angle)
        {
            // Act - performing the action
            Tuple<double, double> results = Calculator.Trig_Calculate_Hypotenuse_Angle(Opposite, Adjacent);
            // Assert - did we get back the correct answer
            Assert.Equal(Hypotenuse, Math.Round(results.Item1, 4));
            Assert.Equal(Angle, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 2.6458, 48.5904)]
        // Student Data
        // STUDENT DATA CHANGED DUE TO THE FACT THAT 10 Opp AND 10 Hyp = 0 Adj... which IS NOT GOOD!
        // Hypotenuse must ALWAYS be the longest side
        [InlineData(7, 10, 7.1414, 44.4270)]
        public void TestCalculateAdjacentTheta(double Opposite, double Hypotenuse, double Adjacent, double Angle)
        {
            // Act - performing the action
            Tuple<double, double> results = Calculator.Trig_Calculate_Adjacent_Angle(Opposite, Hypotenuse);
            // Assert - did we get back the correct answer
            Assert.Equal(Adjacent, Math.Round(results.Item1, 4));
            Assert.Equal(Angle, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 2.6458, 41.4096)]
        // Student Data
        [InlineData(10, 15, 11.1803, 48.1897)]
        public void TestCalculateOppositeTheta(double Adjacent, double Hypotenuse, double Opposite, double Angle)
        {
            // Act - performing the action
            Tuple<double, double> results = Calculator.Trig_Calculate_Opposite_Angle(Adjacent, Hypotenuse);
            // Assert - did we get back the correct answer
            Assert.Equal(Opposite, Math.Round(results.Item1, 4));
            Assert.Equal(Angle, Math.Round(results.Item2, 4));
        }
        #endregion

        #region Vector2D Tests

        public static IEnumerable<Object[]> AddVector2DData()
        {
            // Instructor Data
            yield return new Object[]
            {
            new Eng_Vector2D(3, 4),
            new Eng_Vector2D(6, 9),
            new Eng_Vector2D(9, 13)
            };

            // Student Data
            yield return new Object[]
            {
            new Eng_Vector2D(5, 6),
            new Eng_Vector2D(8, 9),
            new Eng_Vector2D(13, 15)
            };
        }

        public static IEnumerable<Object[]> NormalizeVector2DData()
        {
            // Instructor Data
            yield return new Object[]
            {
            new Eng_Vector2D(3, 4),
            new Eng_Vector2D(0.6, 0.8)
            };

            // Student Data
            yield return new Object[]
            {
            new Eng_Vector2D(5, 6),
            new Eng_Vector2D(0.6402, 0.7682)
            };
        }


        [Theory]
        [MemberData("AddVector2DData")]
        public void TestAddVector(Eng_Vector2D VectorA, Eng_Vector2D VectorB, Eng_Vector2D expectedVector)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]

            // Act - performing the action
            Eng_Vector2D results = Calculator.Vector2D_AddTwo2DVectors(VectorA, VectorB);

            // Assert - did we get back the correct answer
            Assert.Equal(expectedVector.X, Math.Round(results.X, 4));
            Assert.Equal(expectedVector.Y, Math.Round(results.Y, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 6, 9, 3.1798)]
        // Student Data
        [InlineData(5, 1, 3, 4, 41.8202)]
        public void TestAngleBetweenVectors(double Ax, double Ay, double Bx, double By, double expected)
        {
            /* Finding the angle between Vectors...
             * 
             * Angle Between A and A+B = Arcos(Dot Product / (MagOfA * MagOfA+B))
             * and
             * Angle between B and A+B = Arcos(Dot Product / (MagOfB * MagOfA+B))
             */
            double AngleBetweenVectors;
            Eng_Vector2D vectorA = new Eng_Vector2D(Ax, Ay);
            Eng_Vector2D vectorB = new Eng_Vector2D(Bx, By);

            // Act - performing the action
            AngleBetweenVectors = Math.Acos(Calculator.Vector2D_CalculateDotProduct(vectorA, vectorB) / (vectorA.magnitude * vectorB.magnitude));
            AngleBetweenVectors = Calculator.RadiansToDegrees(AngleBetweenVectors);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, Math.Round(AngleBetweenVectors, 4));
        }


        // ATTENTION:
        // This test method is for Part 2(2D Vectors), Question 3, Section B
        // The test data does not provide a test for this, however it is asked for
        // therefore, instructor data is not available.
        [Theory]
        // Student Data
        [InlineData(5, 1, 3, 4, 20.6955)]// Angle between A and A+B
        [InlineData(3, 4, 5, 1, 21.1247)]// Angle between B and A+B

        public void TestAngleBetweenVectorsAndSum(double Ax, double Ay, double Bx, double By, double expected)
        {
            /* Finding the angle between Vectors...
             * 
             * Angle Between A and A+B = Arcos(Dot Product / (MagOfA * MagOfA+B))
             * and
             * Angle between B and A+B = Arcos(Dot Product / (MagOfB * MagOfA+B))
             */
            double AngleBetweenVectors;
            Eng_Vector2D vectorA = new Eng_Vector2D(Ax, Ay);
            Eng_Vector2D vectorAPlusB = new Eng_Vector2D(Ax + Bx, Ay + By);

            // Act - performing the action
            AngleBetweenVectors = Math.Acos(Calculator.Vector2D_CalculateDotProduct(vectorA, vectorAPlusB) / (vectorA.magnitude * vectorAPlusB.magnitude));
            AngleBetweenVectors = Calculator.RadiansToDegrees(AngleBetweenVectors);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, Math.Round(AngleBetweenVectors, 4));
        }

        // VectorA = [5 , 6]
        // ExpectedNormalizedVector = [0.6402, 0.7682]
        [Theory]
        [MemberData("NormalizeVector2DData")]
        public void TestNormalize(Eng_Vector2D VectorA, Eng_Vector2D expectedNormalizedVector)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]

            // Act - performing the action
            Eng_Vector2D results = Calculator.Vector2D_NormalizeVector(VectorA);
            // Assert - did we get back the correct answer
            Assert.Equal(expectedNormalizedVector.X, Math.Round(results.X, 4));
            Assert.Equal(expectedNormalizedVector.Y, Math.Round(results.Y, 4));
        }



        #endregion

        #region Vector3D Tests

        public static IEnumerable<Object[]> CrossProductData()
        {
            // Instructor Data
            yield return new Object[]
            {
                new Eng_Vector3D(3, 4, 5),
                new Eng_Vector3D(6, 9, -1),
                new Eng_Vector3D(-49, 33, 3)
            };
            // Student Data
            yield return new Object[]
            {
                new Eng_Vector3D(5, 6, 2),
                new Eng_Vector3D(2, 9, -6),
                new Eng_Vector3D(-54, 34, 33)
            };

        }

        public static IEnumerable<Object[]> SurfaceNormalData()
        {
            // Instructor Data
            yield return new Object[]
            {
                new Eng_Vector3D(3, 4, 5),
                new Eng_Vector3D(6, 9, -1),
                new Eng_Vector3D(-0.8284, 0.5579, 0.0507)
            };
            // Student Data
            yield return new Object[]
            {
                new Eng_Vector3D(5, 2, 3),
                new Eng_Vector3D(3, 5, 6),
                new Eng_Vector3D(-0.1053, -0.7374, 0.6672)
            };
        }


        [Theory]
        // Instructor Data
        [InlineData(3, 4, 5, 6, 9, -1, 49)]
        // Student Data
        [InlineData(5, 2, 3, 5, 3, 6, 49)]
        public void TestDotProduct3D(double aX, double aY, double aZ, double bX, double bY, double bZ, double expected)
        {
            // Act - performing the action
            double results = Calculator.Vector3D_CalculateDotProduct(new Eng_Vector3D(aX, aY, aZ), new Eng_Vector3D(bX, bY, bZ));
            // Assert - did we get back the correct answer
            Assert.Equal(expected, Math.Round(results, 4));

        }

        [Theory]
        [MemberData("CrossProductData")]
        public void TestCrossProduct(Eng_Vector3D VectorA, Eng_Vector3D VectorB, Eng_Vector3D expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]

            // Act - performing the action
            Eng_Vector3D results = Calculator.Vector3D_CalculateCrossProduct(VectorA, VectorB);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.X, Math.Round(results.X, 4));
            Assert.Equal(expected.Y, Math.Round(results.Y, 4));
            Assert.Equal(expected.Z, Math.Round(results.Z, 4));
        }

        [Theory]
        [MemberData("SurfaceNormalData")]
        public void TestSurfaceNormal(Eng_Vector3D VectorA, Eng_Vector3D VectorB, Eng_Vector3D expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]

            // Act - performing the action
            /// Method was not made for this, as the Lab did not request one to be made.
            /// Therefore we do the calculations in the test itself.
            Eng_Vector3D crossProduct = Calculator.Vector3D_CalculateCrossProduct(VectorA, VectorB);
            Eng_Vector3D normalizedCrossProduct = Calculator.Vector3D_NormalizeVector(crossProduct);

            // Assert - did we get back the correct answer
            Assert.Equal(expected.X, Math.Round(normalizedCrossProduct.X,4));
            Assert.Equal(expected.Y, Math.Round(normalizedCrossProduct.Y, 4));
            Assert.Equal(expected.Z, Math.Round(normalizedCrossProduct.Z, 4));
        }



        #endregion

    }
}
