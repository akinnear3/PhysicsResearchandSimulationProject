﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class simulates a point in 3D LHR space using homogeneous coordinate system (i.e. has the w-axis)
    /// </summary>
    public class Eng_Point4D
    {
    }
}
