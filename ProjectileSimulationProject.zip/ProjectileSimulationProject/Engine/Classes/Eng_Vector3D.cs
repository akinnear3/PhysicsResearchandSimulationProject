﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 3D vector in component form
    /// </summary>
    public class Eng_Vector3D
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
        public double magnitude;

        public Eng_Vector3D() { }

        public Eng_Vector3D(double VectorX, double VectorY, double VectorZ)
        {
            X = VectorX;
            Y = VectorY;
            Z = VectorZ;

            // Calculate the magnitude of this vector
            magnitude = CalculatedMagnitude();
        }

        private double CalculatedMagnitude()
        {
            return Math.Sqrt(Math.Pow(X, 2) + Math.Pow(Y, 2) + Math.Pow(Z, 2));
        }

    }
}
