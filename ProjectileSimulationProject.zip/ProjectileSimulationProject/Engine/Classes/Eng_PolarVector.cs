﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 2D vector with magnitude@direction
    /// </summary>
    public class Eng_PolarVector
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double magnitude;
        public double direction; // In Degrees when passed a value

        public Eng_PolarVector(double Magnitude, double DirectionDegrees)
        {
            SetVectorComponentValues(Magnitude, DirectionDegrees);
        }

        private void SetVectorComponentValues(double Magnitude, double Direction)
        {
            magnitude = Magnitude;
            direction = Direction * Math.PI / 180;
            X = Math.Sin(direction) * magnitude;
            Y = Math.Cos(direction) * magnitude;
        }
    }
}
