﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a Sphere for mathematical calculations.
    /// </summary>
    public class Eng_Sphere
    {
        public Eng_Vector3D Center { get; set; }
        public double Radius { get; set; }
        public double Mass { get; set; }

        public Eng_Sphere(Eng_Vector3D SphereCenter, double R, double M)
        {
            Center = SphereCenter;
            Radius = R;
            Mass = M;
        }

    }
}
