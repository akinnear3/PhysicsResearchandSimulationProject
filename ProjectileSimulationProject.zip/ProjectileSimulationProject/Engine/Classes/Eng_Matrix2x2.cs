﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 2x2  matrix
    /// </summary>
    public class Eng_Matrix2x2
    {
    }
}
