﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a Circle for mathematical calculations.
    /// </summary>
    public class Eng_Circle
    {
        public Eng_Vector2D Center { get; set; }
        public double Radius { get; set; }
        public double Mass { get; set; }


        public Eng_Circle(Eng_Vector2D CircleCenter, double R, double M)
        {
            Center = CircleCenter;
            Radius = R;
            Mass = M;
        }

    }
}
