﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Classes;
using Xunit;

namespace Engine.Specs
{
    public class Lab2Tester
    {
        #region Matrix Multiplication
        public static IEnumerable<Object[]> MatrixMultiplicationData()
        {
            // Instructor Data
            yield return new Object[]
            {
                // Test Datais:
                //   Matrix A
                //   Matrix B
                //   Expected = A x B
                new Eng_Matrix4x4(
                    5, 0, 0, 10,
                    0, 5, 0, 15,
                    0, 0, 1, 2,
                    0, 0, 0, 1),
                new Eng_Matrix4x4(
                    3, 2, -1, 1,
                    0, 2, 3, -1,
                    2, 0, 2, 2,
                    0, 0, 0, 1),
                new Eng_Matrix4x4(
                    15, 10, -5, 15,
                    0, 10, 15, 10,
                    2, 0, 2, 4,
                    0, 0, 0, 1)
            };
            // Student Data
            yield return new Object[]
            {
                // Test Datais:
                //   Matrix A
                //   Matrix B = Inverse of Matrix A
                //   Expected = A x B
                new Eng_Matrix4x4(
                    2, 0, 0, 0.5,
                    0, -2, 0, 1.5,
                    0, 0, 3, 2,
                    0, 0, 0, 1),
                new Eng_Matrix4x4(
                    0.2, 0, 0, -2,
                    0, 0.2, 0, -3,
                    0, 0, 1, -2,
                    0, 0, 0, 1),
                new Eng_Matrix4x4(
                    0.4, 0, 0, -3.5,
                    0, -0.4, 0, 7.5,
                    0, 0, 3, -4,
                    0, 0, 0, 1)
             };

        }

        public static IEnumerable<Object[]> MatrixVectorMultiplicationData()
        {
            // Instructor Data
            yield return new Object[]
            {
                // Test Data is:
                //   Matrix M
                //   Vector V
                //   Expected = M x V
                new Eng_Matrix4x4(
                    2, 0, 0, 0.5,
                    0, -2, 0, 1.5,
                    0, 0, 3, 2,
                    0, 0, 0, 1),
                new Eng_Vector4D(-2, 3, -5, 1),
                new Eng_Vector4D(-3.5, -4.5, -13, 1)
            };
            // Student Data
            yield return new Object[]
            {
                // Test Data is:
                //   Matrix M
                //   Vector V
                //   Expected = M x V
                new Eng_Matrix4x4(
                    5, 0, 0, 10,
                    0, 5, 0, 15,
                    0, 0, 1, 2,
                    0, 0, 0, 1),
                new Eng_Vector4D(3, 5, 7, 1),
                new Eng_Vector4D(25, 40, 9, 1)
            };

            // Test the multiplication of the inverse transformation matrix and the transformed point (step a)
            yield return new Object[]
            {
                // Test Data is:
                //   Matrix M = Inverse of Transformation Matrix
                //   Vector V = Transformed Point
                //   Expected = M x V
                new Eng_Matrix4x4(0.2, 0, 0, -2,
                                  0, 0.2, 0, -3,
                                  0, 0, 1, -2,
                                  0, 0, 0, 1),
                new Eng_Vector4D(-3.5, -4.5, -13, 1),
                new Eng_Vector4D(-2.7, -3.9, -15, 1)
            };
        }

        public static IEnumerable<Object[]> TransposeMatrixData()
        {
            // Instructor Data
            yield return new Object[]
            {
                // Test Data is:
                //   Matrix M
                //   Expected = M^T
                new Eng_Matrix4x4(
                    2, 0, 0, 0.5,
                    0, -2, 0, 1.5,
                    0, 0, 3, 2,
                    0, 0, 0, 1),
               new Eng_Matrix4x4(
                   2, 0, 0, 0,
                   0, -2, 0, 0,
                   0, 0, 3, 0,
                   0.5, 1.5, 2, 1)
            };
            // Student Data
            yield return new Object[]
           {
                // Test Data is:
                //   Matrix M
                //   Expected = M^T
                new Eng_Matrix4x4(
                    5, 3, 2, 1,
                    0, 6, 0, 2,
                    7, 0, 6, 3,
                    0, 4, 0, 5),
               new Eng_Matrix4x4(
                   5, 0, 7, 0,
                   3, 6, 0, 4,
                   2, 0, 6, 0,
                   1, 2, 3, 5)
           };
        }

        public static IEnumerable<Object[]> InverseMatrixData()
        {
            // Instructor Data
            yield return new Object[]
            {
                // Test Data is:
                //   Matrix M
                //   Expected = M^-1
                new Eng_Matrix4x4(
                    2, 0, 0, 0.5,
                    0, -2, 0, 1.5,
                    0, 0, 3, 2,
                    0, 0, 0, 1),
               new Eng_Matrix4x4(
                   0.5, 0, 0, -0.25,
                   0, -0.5, 0, 0.75,
                   0, 0, 0.3333, -0.6667,
                   0, 0, 0, 1)
            };
            // Student Data
            yield return new Object[]
            {
                // Test Data is:
                //   Matrix M
                //   Expected = M^-1
                new Eng_Matrix4x4(
                    5, 0, 0, 10,
                    0, 5, 0, 15,
                    0, 0, 1, 2,
                    0, 0, 0, 1),
                new Eng_Matrix4x4(
                   0.2, 0, 0, -2,
                   0, 0.2, 0, -3,
                   0, 0, 1, -2,
                   0, 0, 0, 1)
            };


        }

        [Theory]
        [MemberData("MatrixMultiplicationData")]
        public void TestMultiplyMatrices4(Eng_Matrix4x4 givenA, Eng_Matrix4x4 givenB, Eng_Matrix4x4 expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Matrix4x4 results = Calculator.Matrix4x4_Multiply4x4MatrixAnd4x4Matrix(givenA, givenB);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.m11, results.m11);
            Assert.Equal(expected.m12, results.m12);
            Assert.Equal(expected.m13, results.m13);
            Assert.Equal(expected.m14, results.m14);
            Assert.Equal(expected.m21, results.m21);
            Assert.Equal(expected.m22, results.m22);
            Assert.Equal(expected.m23, results.m23);
            Assert.Equal(expected.m24, results.m24);
            Assert.Equal(expected.m31, results.m31);
            Assert.Equal(expected.m32, results.m32);
            Assert.Equal(expected.m33, results.m33);
            Assert.Equal(expected.m34, results.m34);
            Assert.Equal(expected.m41, results.m41);
            Assert.Equal(expected.m42, results.m42);
            Assert.Equal(expected.m43, results.m43);
            Assert.Equal(expected.m44, results.m44);
        }

        [Theory]
        [MemberData("MatrixVectorMultiplicationData")]
        public void TestMultiplyVector4ByMatrix(Eng_Matrix4x4 givenM, Eng_Vector4D givenV, Eng_Vector4D expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Vector4D results = Calculator.Vector4D_MultiplyVector4DAnd4x4Matrix(givenV, givenM);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.X, results.X);
            Assert.Equal(expected.Y, results.Y);
            Assert.Equal(expected.Z, results.Z);
            Assert.Equal(expected.W, results.W);            // W is always 1, however it's still good to test it
        }

        [Theory]
        [MemberData("TransposeMatrixData")]
        public void TestTranposeMatrix(Eng_Matrix4x4 given, Eng_Matrix4x4 expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Matrix4x4 results = Calculator.Matrix4x4_Transpose4x4Matrix(given);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.m11, results.m11);
            Assert.Equal(expected.m12, results.m12);
            Assert.Equal(expected.m13, results.m13);
            Assert.Equal(expected.m14, results.m14);
            Assert.Equal(expected.m21, results.m21);
            Assert.Equal(expected.m22, results.m22);
            Assert.Equal(expected.m23, results.m23);
            Assert.Equal(expected.m24, results.m24);
            Assert.Equal(expected.m31, results.m31);
            Assert.Equal(expected.m32, results.m32);
            Assert.Equal(expected.m33, results.m33);
            Assert.Equal(expected.m34, results.m34);
            Assert.Equal(expected.m41, results.m41);
            Assert.Equal(expected.m42, results.m42);
            Assert.Equal(expected.m43, results.m43);
            Assert.Equal(expected.m44, results.m44);
        }

        [Theory]
        // Instructor Data
        [InlineData(2, 0, 0, 0.5, 0, -2, 0, 1.5, 0, 0, 3, 2, 0, 0, 0, 1, -12)]
        // Student Data
        [InlineData(5, 0, 0, 10, 0, 5, 0, 15, 0, 0, 1, 2, 0, 0, 0, 1, 25)]

        public void TestDeterminant4(
            double m11, double m12, double m13, double m14,
            double m21, double m22, double m23, double m24,
            double m31, double m32, double m33, double m34,
            double m41, double m42, double m43, double m44,
            double expected)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            double results = Calculator.Matrix4x4_DeterminantOfMatrix(m11, m12, m13, m14, m21, m22, m23, m24, m31, m32, m33, m34, m41, m42, m43, m44);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, results);
        }

        [Theory]
        [MemberData("InverseMatrixData")]
        public void TestInverse4(Eng_Matrix4x4 given, Eng_Matrix4x4 expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Matrix4x4 results = Calculator.Matrix4x4_InverseOfMatrix(given);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.m11, Math.Round(results.m11, 4));
            Assert.Equal(expected.m12, Math.Round(results.m12, 4));
            Assert.Equal(expected.m13, Math.Round(results.m13, 4));
            Assert.Equal(expected.m14, Math.Round(results.m14, 4));
            Assert.Equal(expected.m21, Math.Round(results.m21, 4));
            Assert.Equal(expected.m22, Math.Round(results.m22, 4));
            Assert.Equal(expected.m23, Math.Round(results.m23, 4));
            Assert.Equal(expected.m24, Math.Round(results.m24, 4));
            Assert.Equal(expected.m31, Math.Round(results.m31, 4));
            Assert.Equal(expected.m32, Math.Round(results.m32, 4));
            Assert.Equal(expected.m33, Math.Round(results.m33, 4));
            Assert.Equal(expected.m34, Math.Round(results.m34, 4));
            Assert.Equal(expected.m41, Math.Round(results.m41, 4));
            Assert.Equal(expected.m42, Math.Round(results.m42, 4));
            Assert.Equal(expected.m43, Math.Round(results.m43, 4));
            Assert.Equal(expected.m44, Math.Round(results.m44, 4));
        }
        #endregion

        #region 2D Rotation
        [Theory]
        // Instructor Data
        [InlineData(3, -1, -4, 5, 2, 3, 25, 3.1415, 0.3615, -5.7383, 2.8411, 0.5448, 3.5642)]
        // Student Data
        [InlineData(2, 5, 1, 3, 5, 2, 30, -0.7679, 5.3301, -0.6340, 3.0981, 3.3301, 4.2321)]
        public void TestRotation2D(
            double x1, double y1, double x2, double y2, double x3, double y3, double degrees,
            double expectedx1, double expectedy1,
            double expectedx2, double expectedy2,
            double expectedx3, double expectedy3)
        {
            // Arrange - get data to do the test
            // Act - performing the action
            Eng_Vector3D results1 = Calculator.Rotation_Rotate2DPointByDegrees(x1, y1, degrees);
            Eng_Vector3D results2 = Calculator.Rotation_Rotate2DPointByDegrees(x2, y2, degrees);
            Eng_Vector3D results3 = Calculator.Rotation_Rotate2DPointByDegrees(x3, y3, degrees);

            // Assert - did we get back the correct answer
            Assert.Equal(expectedx1, Math.Round(results1.X, 4));
            Assert.Equal(expectedy1, Math.Round(results1.Y, 4));

            Assert.Equal(expectedx2, Math.Round(results2.X, 4));
            Assert.Equal(expectedy2, Math.Round(results2.Y, 4));

            Assert.Equal(expectedx3, Math.Round(results3.X, 4));
            Assert.Equal(expectedy3, Math.Round(results3.Y, 4));
        }
        #endregion

        #region 3D Rotation

        /*  IMPORTANT STUDENT DATA:
            From Lab02 Documentation:
            3.In the Lab2_Tester.cs file you will create three 3D points using the Eng_Vector4D.cs class 

           My three 3D Points:
              #1:   [3, 2, 5, 1]
              #2:   [4, 3, 2, 1]
              #3:   [6, 4, 2, 1]
           My three Euler Angles (Degrees):
              Roll:    20 Degrees
              Pitch:   5 Degrees
              Yaw:     30 Degrees
        */

        public static IEnumerable<Object[]> QuaternionToMatrixData()
        {
            // Instructor Data
            yield return new Object[]
            {
                // Test Data is:
                //   Quaternion Q
                //   Expected = M
                new Eng_Quaternion(15, 10, 5),
                new Eng_Matrix4x4(
                    0.9662, -0.2432, 0.0858, 0,
                    0.2549, 0.9513, -0.1736, 0,
                    -0.0394, 0.1897, 0.9811, 0,
                    0, 0, 0, 1)

            };
            // Student Data
            yield return new Object[]
            {
                // Test Data is:
                //   Quaternion Q
                //   Expected = M
                new Eng_Quaternion(20, 5, 30),
                // w = 0.9523
                // x = 0.0864
                // y = 0.2473
                // z = 0.1565
                new Eng_Matrix4x4(
                    0.8287, -0.2552, 0.4981, 0,
                    0.3407, 0.9361, -0.0872, 0,
                    -0.4440, 0.2419, 0.8627, 0,
                    0, 0, 0, 1)
                    
            };

        }

        public static IEnumerable<Object[]> Rotate3DData()
        {

            // Instructor Data
            yield return new Object[]
            {
                // Test Data is:
                //   Vector V
                //   Quaternion V
                //   Expected = Q x V, converting Q to Matrix R,
                //            = R x V 
                new Eng_Vector4D(-2, 5, 3, 1),
                new Eng_Quaternion(15, 10, 5),
                new Eng_Vector4D(-2.8909, 3.7255, 3.9703, 1)

            };
            // Student Data

            // 3DPoint #1
            yield return new Object[]
            {
                // Test Data is:
                //   Vector V
                //   Quaternion V
                //   Expected = Q x V, converting Q to Matrix R,
                //            = R x V 
                new Eng_Vector4D(3, 2, 5, 1),
                new Eng_Quaternion(20, 5, 30),
                new Eng_Vector4D(4.4661, 2.4586, 3.4654, 1)

            };

            // 3DPoint #2
            yield return new Object[]
           {
                // Test Data is:
                //   Vector V
                //   Quaternion V
                //   Expected = Q x V, converting Q to Matrix R,
                //            = R x V 
                new Eng_Vector4D(4, 3, 2, 1),
                new Eng_Quaternion(20, 5, 30),
                new Eng_Vector4D(3.5453, 3.9969, 0.6751, 1)

           };
            // 3DPoint #3
            yield return new Object[]
           {
                // Test Data is:
                //   Vector V
                //   Quaternion V
                //   Expected = Q x V, converting Q to Matrix R,
                //            = R x V 
                new Eng_Vector4D(6, 4, 2, 1),
                new Eng_Quaternion(20, 5, 30),
                new Eng_Vector4D(4.9474, 5.6145, 0.029, 1)

           };
        }

        [Theory]
        // Instructor Data
        [InlineData(15, 10, 5, 0.98722829, 0.09199968, 0.03171637, 0.12613659)]

        // Student Data
        [InlineData(20, 5, 30, 0.95230627, 0.08639368, 0.24732807, 0.15645360)]
        public void TestQuaternion(
            double bank, double attitude, double heading,
            double expectedQw, double expectedQx, double expectedQy, double expectedQz)
        {
            // Arrange - get data to do the test
            // Act - performing the action
            Eng_Quaternion Q = new Eng_Quaternion(bank, attitude, heading);
            // Assert - did we get back the correct answer
            Assert.Equal(expectedQw, Math.Round(Q.w, 8));
            Assert.Equal(expectedQx, Math.Round(Q.x, 8));
            Assert.Equal(expectedQy, Math.Round(Q.y, 8));
            Assert.Equal(expectedQz, Math.Round(Q.z, 8));
        }

        [Theory]
        [MemberData("QuaternionToMatrixData")]
        public void TestQuaternionToMatrix(Eng_Quaternion q, Eng_Matrix4x4 expected)
        {
            // Arrange - get data to do the test
            // This method uses MemberData
            // Act - performing the action
            Eng_Matrix4x4 results = Calculator.QuaternionToMatrix(q);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.m11, Math.Round(results.m11, 4));
            Assert.Equal(expected.m12, Math.Round(results.m12, 4));
            Assert.Equal(expected.m13, Math.Round(results.m13, 4));
            Assert.Equal(expected.m14, Math.Round(results.m14, 4));
            Assert.Equal(expected.m21, Math.Round(results.m21, 4));
            Assert.Equal(expected.m22, Math.Round(results.m22, 4));
            Assert.Equal(expected.m23, Math.Round(results.m23, 4));
            Assert.Equal(expected.m24, Math.Round(results.m24, 4));
            Assert.Equal(expected.m31, Math.Round(results.m31, 4));
            Assert.Equal(expected.m32, Math.Round(results.m32, 4));
            Assert.Equal(expected.m33, Math.Round(results.m33, 4));
            Assert.Equal(expected.m34, Math.Round(results.m34, 4));
            Assert.Equal(expected.m41, Math.Round(results.m41, 4));
            Assert.Equal(expected.m42, Math.Round(results.m42, 4));
            Assert.Equal(expected.m43, Math.Round(results.m43, 4));
            Assert.Equal(expected.m44, Math.Round(results.m44, 4));
        }

        [Theory]
        [MemberData("Rotate3DData")]
        public void TestRotate3D(Eng_Vector4D v, Eng_Quaternion q, Eng_Vector4D expected)
        {
            // Arrange - get data to do the test
            // This method uses MemberData
            // Act - performing the action
            Eng_Vector4D results = Calculator.Rotation_Rotate3D(v, q);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.W, Math.Round(results.W, 4));
            Assert.Equal(expected.X, Math.Round(results.X, 4));
            Assert.Equal(expected.Y, Math.Round(results.Y, 4));
            Assert.Equal(expected.Z, Math.Round(results.Z, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(0.98722829, 0.09199968, 0.03171637, 0.12613659, 15, 10, 5)]
        // Student Data
        [InlineData(0.95230627, 0.08639368, 0.24732807, 0.15645360, 20, 5, 30)]
        public void TestQuaterionToEuler(double qW, double qX, double qY, double qZ,
            double expectedRoll, double expectedPitch, double expectedYaw)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            Tuple<double,double,double> results = Calculator.QuaternionToEuler(qW, qX, qY, qZ);

            // Assert - did we get back the correct answer
            Assert.Equal(expectedRoll, Math.Round(results.Item1));
            Assert.Equal(expectedPitch, Math.Round(results.Item2));
            Assert.Equal(expectedYaw, Math.Round(results.Item3));
        }
        #endregion
    }
}

