﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Classes;

namespace Engine
{
    /// <summary>
    /// This class contains static methods to perform the math calculations.
    /// </summary> 
    public class Calculator
    {
        // For Lab03
        public const double G = 6.673e-11;

        #region Lab01
        #region Eng_Point2D Methods
        /// <summary>
        /// Calculates the length of a line segment between two 2D points.
        /// </summary>
        /// <param name="a">Eng_Point2D: a 2D point A</param>
        /// <param name="b">Eng_Point2D: a 2D point B</param>
        /// <returns>Double: length of the line segment.</returns>
        public static double SegmentLength(Eng_Point2D a, Eng_Point2D b)
        {
            return Math.Sqrt(Math.Pow(b.x - a.x, 2) + Math.Pow(b.y - a.y, 2));
        }

        /// <summary>
        /// Calculates the midpoint of the line segment between two 2D points.
        /// </summary>
        /// <param name="a">Eng_Point2D: a 2D point A</param>
        /// <param name="b">Eng_Point2D: a 2D point B</param>
        /// <returns>Eng_Point2D: midpoint on the line segemnt</returns>
        public static Eng_Point2D MidPoint(Eng_Point2D a, Eng_Point2D b)
        {
            return new Eng_Point2D(0.5 * (a.x + b.x), 0.5 * (a.y + b.y));
        }
        #endregion

        #region Angle Conversion Methods
        // a.	A method to convert Degrees to Radians
        public static double DegreesToRadians(double Degrees)
        {
            if (Degrees == 0)
            {
                return 0;
            }
            else
            {
                // Calculates and Returns the Radians
                return (Degrees * Math.PI) / 180; ;
            }
        }

        // b.	A method to convert Radians to Degrees
        public static double RadiansToDegrees(double Radians)
        {
            if (Radians == 0)
            {
                return 0;
            }
            else
            {
                // Returns the Degrees
                return (Radians * 180) / Math.PI;
            }
        }
        #endregion

        #region Trigonometry Methods
        // c.	A method to solve a right triAngle given an Angle in Degrees and the Hypotenuse; 
        // returns a Tuple<double, double> for the missing sides (Adjacent, Opposite).
        public static Tuple<double, double> Trig_Calculate_Adjacent_Opposite(double Angle, double Hypotenuse)
        {
            // SOH CAH TOA
            Angle = Calculator.DegreesToRadians(Angle);

            return new Tuple<double, double>(Math.Cos(Angle) * Hypotenuse, Math.Sin(Angle) * Hypotenuse);
        }

        //d.	A method to solve a right triAngle given an Angle in degrees and the side opposite;
        //      returns a Tuple<double, double> for the missing sides (adjacent, hypotenuse).
        public static Tuple<double, double> Trig_Calculate_Adjacent_Hypotenuse(double Angle, double Opposite)
        {
            // Convert Angle to Rads
            Angle = Calculator.DegreesToRadians(Angle);

            return new Tuple<double, double>(Opposite / Math.Tan(Angle), Opposite / Math.Sin(Angle));
        }

        //e.	A method to solve a right triangle given an angle in degrees and the side adjacent; 
        //      returns a Tuple<double, double> for the missing sides (opposite, hypotenuse).
        public static Tuple<double, double> Trig_Calculate_Opposite_Hypotenuse(double Angle, double Adjacent)
        {
            Angle = Calculator.DegreesToRadians(Angle);

            return new Tuple<double, double>(Math.Tan(Angle) * Adjacent, Adjacent / Math.Cos(Angle));
        }

        //f.	A method to solve a right triangle given side opposite and side adjacent; 
        //      returns a Tuple<double, double> for the missing side and the angle in degrees
        public static Tuple<double, double> Trig_Calculate_Hypotenuse_Angle(double Opposite, double Adjacent)
        {
            return new Tuple<double, double>(
                Math.Sqrt(Math.Pow(Adjacent, 2) + Math.Pow(Opposite, 2)),
                Calculator.RadiansToDegrees(Math.Atan(Opposite / Adjacent)));
        }

        //g.    A method to solve a right triangle given side opposite and hypotenuse; 
        //      returns a Tuple<double, double> for the missing side and the angle in degrees
        public static Tuple<double, double> Trig_Calculate_Adjacent_Angle(double Opposite, double Hypotenuse)
        {
            return new Tuple<double, double>(
                Math.Sqrt(Math.Pow(Hypotenuse, 2) - Math.Pow(Opposite, 2)), 
                Calculator.RadiansToDegrees(Math.Asin(Opposite / Hypotenuse)));
        }

        //h.    A method to solve a right triangle given side adjacent and hypotenuse; 
        //      returns a Tuple<double, double> for the missing side and the angle in degrees
        public static Tuple<double, double> Trig_Calculate_Opposite_Angle(double Adjacent, double Hypotenuse)
        {
            return new Tuple<double, double>(
                Math.Sqrt(Math.Pow(Hypotenuse, 2) - Math.Pow(Adjacent, 2)), 
                Calculator.RadiansToDegrees(Math.Acos(Adjacent / Hypotenuse)));
        }
        #endregion

        #region Vector2D Methods
        public static Eng_Vector2D Vector2D_AddTwo2DVectors(Eng_Vector2D vectorA, Eng_Vector2D vectorB)
        {
            return new Eng_Vector2D(vectorA.X + vectorB.X, vectorA.Y + vectorB.Y); ;
        }

        public static double Vector2D_CalculateDotProduct(Eng_Vector2D VectorA, Eng_Vector2D VectorB)
        {
            return VectorA.X * VectorB.X + VectorA.Y * VectorB.Y;
        }

        public static double Vector2D_CalculateAngleBetweenVectors(Eng_Vector2D VectorA, Eng_Vector2D VectorB)
        {
            return Math.Acos(Vector2D_CalculateDotProduct(VectorA, VectorB) / (VectorA.magnitude * VectorB.magnitude));
        }

        public static Eng_Vector2D Vector2D_NormalizeVector(Eng_Vector2D VectorA)
        {
            return new Eng_Vector2D(
                Math.Round(VectorA.X / VectorA.magnitude, 4),  // Normalized X
                Math.Round(VectorA.Y / VectorA.magnitude, 4)); // Normalized Y
        }



        #endregion

        #region Vector3D Methods

        public static Eng_Vector3D Vector3D_AddTwo3DVectors (Eng_Vector3D VectorA, Eng_Vector3D VectorB)
        {
            return new Eng_Vector3D(
                VectorA.X + VectorB.X,  //cX
                VectorA.Y + VectorB.Y,  //cY
                VectorA.Z + VectorB.Z); //cZ
        }


        public static double Vector3D_CalculateDotProduct(Eng_Vector3D VectorA, Eng_Vector3D VectorB)
        {
            return 
                VectorA.X * VectorB.X + 
                VectorA.Y * VectorB.Y + 
                VectorA.Z * VectorB.Z;
        }

        public static Eng_Vector3D Vector3D_CalculateCrossProduct(Eng_Vector3D VectorA, Eng_Vector3D VectorB)
        {
            return new Eng_Vector3D(
                (VectorA.Y * VectorB.Z) - (VectorA.Z * VectorB.Y),
                (VectorA.Z * VectorB.X) - (VectorA.X * VectorB.Z),
                (VectorA.X * VectorB.Y) - (VectorA.Y * VectorB.X));
        }

        public static double Vector3D_CalculateAngleBetweenVectors(Eng_Vector3D VectorA, Eng_Vector3D VectorB)
        {
            return Math.Acos(Vector3D_CalculateDotProduct(VectorA, VectorB) / (VectorA.magnitude * VectorB.magnitude));
        }

        public static Eng_Vector3D Vector3D_NormalizeVector(Eng_Vector3D VectorA)
        {
            return new Eng_Vector3D((VectorA.X / VectorA.magnitude), (VectorA.Y / VectorA.magnitude), (VectorA.Z / VectorA.magnitude));
        }


        #endregion
        #endregion

        #region Lab02
            #region Part 1 – Matrix Transformation in 2D
        public static Eng_Vector4D Vector4D_MultiplyVector4DAnd4x4Matrix(Eng_Vector4D Vector, Eng_Matrix4x4 Matrix)
        {

            return new Eng_Vector4D(
                (Matrix.m11 * Vector.X) + (Matrix.m12 * Vector.Y) + (Matrix.m13 * Vector.Z) + (Matrix.m14 * Vector.W), 
                (Matrix.m21 * Vector.X) + (Matrix.m22 * Vector.Y) + (Matrix.m23 * Vector.Z) + (Matrix.m24 * Vector.W),
                (Matrix.m31 * Vector.X) + (Matrix.m32 * Vector.Y) + (Matrix.m33 * Vector.Z) + (Matrix.m34 * Vector.W),
                (Matrix.m41 * Vector.X) + (Matrix.m42 * Vector.Y) + (Matrix.m43 * Vector.Z) + (Matrix.m44 * Vector.W)
                );
        }

        public static Eng_Matrix4x4 Matrix4x4_Multiply4x4MatrixAnd4x4Matrix(Eng_Matrix4x4 A, Eng_Matrix4x4 B)
        {
            return new Eng_Matrix4x4(
                (A.m11 * B.m11) + (A.m12 * B.m21) + (A.m13 * B.m31) + (A.m14 * B.m41),
                (A.m11 * B.m12) + (A.m12 * B.m22) + (A.m13 * B.m32) + (A.m14 * B.m42),
                (A.m11 * B.m13) + (A.m12 * B.m23) + (A.m13 * B.m33) + (A.m14 * B.m43),
                (A.m11 * B.m14) + (A.m12 * B.m24) + (A.m13 * B.m34) + (A.m14 * B.m44),

                (A.m21 * B.m11) + (A.m22 * B.m21) + (A.m23 * B.m31) + (A.m24 * B.m41),
                (A.m21 * B.m12) + (A.m22 * B.m22) + (A.m23 * B.m32) + (A.m24 * B.m42),
                (A.m21 * B.m13) + (A.m22 * B.m23) + (A.m23 * B.m33) + (A.m24 * B.m43),
                (A.m21 * B.m14) + (A.m22 * B.m24) + (A.m23 * B.m34) + (A.m24 * B.m44),

                (A.m31 * B.m11) + (A.m32 * B.m21) + (A.m33 * B.m31) + (A.m34 * B.m41),
                (A.m31 * B.m12) + (A.m32 * B.m22) + (A.m33 * B.m32) + (A.m34 * B.m42),
                (A.m31 * B.m13) + (A.m32 * B.m23) + (A.m33 * B.m33) + (A.m34 * B.m43),
                (A.m31 * B.m14) + (A.m32 * B.m24) + (A.m33 * B.m34) + (A.m34 * B.m44),

                (A.m41 * B.m11) + (A.m42 * B.m21) + (A.m43 * B.m31) + (A.m44 * B.m41),
                (A.m41 * B.m12) + (A.m42 * B.m22) + (A.m43 * B.m32) + (A.m44 * B.m42),
                (A.m41 * B.m13) + (A.m42 * B.m23) + (A.m43 * B.m33) + (A.m44 * B.m43),
                (A.m41 * B.m14) + (A.m42 * B.m24) + (A.m43 * B.m34) + (A.m44 * B.m44)
                );
        }


        public static Eng_Matrix4x4 Matrix4x4_Transpose4x4Matrix(Eng_Matrix4x4 Matrix)
        {
            return new Eng_Matrix4x4(Matrix.m11, Matrix.m21, Matrix.m31, Matrix.m41, 
                                     Matrix.m12, Matrix.m22, Matrix.m32, Matrix.m42, 
                                     Matrix.m13, Matrix.m23, Matrix.m33, Matrix.m43,
                                     Matrix.m14, Matrix.m24, Matrix.m34, Matrix.m44);
        }

        public static double Matrix4x4_DeterminantOfMatrix(double m11, double m12, double m13, double m14,
            double m21, double m22, double m23, double m24,
            double m31, double m32, double m33, double m34,
            double m41, double m42, double m43, double m44)
        {
            return ((m11*m22*m33*m44 + m12*m23*m34*m41 + m13*m24*m31*m42 + m14*m21*m32*m43)
                    - (m14*m23*m32*m41 - m13*m22*m31*m44 - m12*m21*m34*m43 - m11*m24*m33*m42));
        }

        public static double Matrix3x3_DeterminantOfMatrix(double m11, double m12, double m13,
    double m21, double m22, double m23,
    double m31, double m32, double m33)
        {
            return (m11*m22*m33 + m12*m23*m31 + m13*m21*m32 
                    - m13*m22*m31 - m12*m21*m33 - m11*m23*m32);
        }


        public static Eng_Matrix4x4 Matrix4x4_InverseOfMatrix(Eng_Matrix4x4 Matrix)
        {
            /*  NOTES:
             *  The creation of an Adjoint matrix involves creating a new matrix which is made up of cofactors, 
             *  calculating the determinant of each cofactor matrix, then transposing the matrix.
             *  InverseM = 1 /determinant * 𝑎𝑑𝑗𝑀
             *  
             *  Adjoint Matrix:
             *  C11 Remove row 1 and column 1. Remaining numbers make a cofactor matrix.
             *  Then find the determinant of the cofactor (diagonal method)
             *  Then transpose the resulting Matrix.
             */

            Eng_Matrix4x4 adjointMatrix = Calculator.Matrix4x4_Transpose4x4Matrix(new Eng_Matrix4x4(
                #region C1#
                // C11
                Calculator.Matrix3x3_DeterminantOfMatrix
                (
                    Matrix.m22, Matrix.m23, Matrix.m24,
                    Matrix.m32, Matrix.m33, Matrix.m34,
                    Matrix.m42, Matrix.m43, Matrix.m44),
                // C12
                Calculator.Matrix3x3_DeterminantOfMatrix
                (
                    Matrix.m21, Matrix.m23, Matrix.m24,
                    Matrix.m31, Matrix.m33, Matrix.m34,
                    Matrix.m41, Matrix.m43, Matrix.m44) * -1,
                // C13
                Calculator.Matrix3x3_DeterminantOfMatrix
                (
                    Matrix.m21, Matrix.m22, Matrix.m24,
                    Matrix.m31, Matrix.m32, Matrix.m34,
                    Matrix.m41, Matrix.m42, Matrix.m44),
                // C14
                Calculator.Matrix3x3_DeterminantOfMatrix
                (
                    Matrix.m21, Matrix.m22, Matrix.m23,
                    Matrix.m31, Matrix.m32, Matrix.m33,
                    Matrix.m41, Matrix.m42, Matrix.m43) * -1,
            #endregion

                #region C2#

                // C21
                Calculator.Matrix3x3_DeterminantOfMatrix
                (
                    Matrix.m12, Matrix.m13, Matrix.m14,
                    Matrix.m32, Matrix.m33, Matrix.m34,
                    Matrix.m42, Matrix.m43, Matrix.m44) * -1,
                // C22
                Calculator.Matrix3x3_DeterminantOfMatrix
                (
                    Matrix.m11, Matrix.m13, Matrix.m14,
                    Matrix.m31, Matrix.m33, Matrix.m34,
                    Matrix.m41, Matrix.m43, Matrix.m44),
                // C23
                Calculator.Matrix3x3_DeterminantOfMatrix
                (
                    Matrix.m11, Matrix.m12, Matrix.m14,
                    Matrix.m31, Matrix.m32, Matrix.m34,
                    Matrix.m41, Matrix.m42, Matrix.m44) * -1,
                // C24
                Calculator.Matrix3x3_DeterminantOfMatrix(
                    Matrix.m11, Matrix.m12, Matrix.m13,
                    Matrix.m31, Matrix.m32, Matrix.m33,
                    Matrix.m41, Matrix.m42, Matrix.m43),
            #endregion

                #region C3#
                Calculator.Matrix3x3_DeterminantOfMatrix(
                    Matrix.m12, Matrix.m13, Matrix.m14,
                    Matrix.m22, Matrix.m23, Matrix.m24,
                    Matrix.m42, Matrix.m43, Matrix.m44),
                Calculator.Matrix3x3_DeterminantOfMatrix(
                    Matrix.m11, Matrix.m13, Matrix.m14,
                    Matrix.m21, Matrix.m23, Matrix.m24,
                    Matrix.m41, Matrix.m43, Matrix.m44) * -1,
                Calculator.Matrix3x3_DeterminantOfMatrix(
                    Matrix.m11, Matrix.m12, Matrix.m14,
                    Matrix.m21, Matrix.m22, Matrix.m24,
                    Matrix.m41, Matrix.m42, Matrix.m44),
                Calculator.Matrix3x3_DeterminantOfMatrix(
                    Matrix.m11, Matrix.m12, Matrix.m13,
                    Matrix.m21, Matrix.m22, Matrix.m23,
                    Matrix.m41, Matrix.m42, Matrix.m43) * -1,
            #endregion

                #region C4#

                Calculator.Matrix3x3_DeterminantOfMatrix(
                Matrix.m12, Matrix.m13, Matrix.m14,
                Matrix.m22, Matrix.m23, Matrix.m24,
                Matrix.m32, Matrix.m33, Matrix.m34) * -1,
                Calculator.Matrix3x3_DeterminantOfMatrix(
                Matrix.m11, Matrix.m13, Matrix.m14,
                Matrix.m21, Matrix.m23, Matrix.m24,
                Matrix.m31, Matrix.m33, Matrix.m34),
                Calculator.Matrix3x3_DeterminantOfMatrix(
                Matrix.m11, Matrix.m12, Matrix.m14,
                Matrix.m21, Matrix.m22, Matrix.m24,
                Matrix.m31, Matrix.m32, Matrix.m34) * -1,
                Calculator.Matrix3x3_DeterminantOfMatrix(
                Matrix.m11, Matrix.m12, Matrix.m13,
                Matrix.m21, Matrix.m22, Matrix.m23,
                Matrix.m31, Matrix.m32, Matrix.m33)
                #endregion
                ));

            double scalarMultiplier =  (1 / Calculator.Matrix4x4_DeterminantOfMatrix(
                Matrix.m11, Matrix.m12, Matrix.m13, Matrix.m14, 
                Matrix.m21, Matrix.m22, Matrix.m23, Matrix.m24, 
                Matrix.m31, Matrix.m32, Matrix.m33, Matrix.m34, 
                Matrix.m41, Matrix.m42, Matrix.m43, Matrix.m44));

            return new Eng_Matrix4x4(
                scalarMultiplier * adjointMatrix.m11, scalarMultiplier * adjointMatrix.m12, scalarMultiplier * adjointMatrix.m13, scalarMultiplier * adjointMatrix.m14,
                scalarMultiplier * adjointMatrix.m21, scalarMultiplier * adjointMatrix.m22, scalarMultiplier * adjointMatrix.m23, scalarMultiplier * adjointMatrix.m24,
                scalarMultiplier * adjointMatrix.m31, scalarMultiplier * adjointMatrix.m32, scalarMultiplier * adjointMatrix.m33, scalarMultiplier * adjointMatrix.m34,
                scalarMultiplier * adjointMatrix.m41, scalarMultiplier * adjointMatrix.m42, scalarMultiplier * adjointMatrix.m43, scalarMultiplier * adjointMatrix.m44);
        }
        #endregion

            #region Part 2 – 2D Rotations
        public static Eng_Vector3D Vector3D_MultiplyVector3DAnd3x3Matrix(Eng_Vector3D Vector, Eng_Matrix3x3 Matrix)
        {
            return new Eng_Vector3D(Vector.X * Matrix.m11 + Vector.Y * Matrix.m21 + Vector.Z * Matrix.m31,
                                    Vector.X * Matrix.m12 + Vector.Y * Matrix.m22 + Vector.Z * Matrix.m32,
                                    Vector.X * Matrix.m13 + Vector.Y * Matrix.m23 + Vector.Z * Matrix.m33);
        }

        public static Eng_Vector3D Rotation_Rotate2DPointByDegrees(double x, double y, double degrees)
        {
            return new Eng_Vector3D(Math.Cos(DegreesToRadians(degrees)) * x + (-Math.Sin(DegreesToRadians(degrees))) * y,
                                    Math.Sin(DegreesToRadians(degrees)) * x + Math.Cos(DegreesToRadians(degrees)) * y,
                                    1);
        }
        #endregion

            #region Part 3 - 3D Rotations
        public static Eng_Matrix4x4 QuaternionToMatrix(Eng_Quaternion Q)
        {
            /*
             * 1 = Roll
             * 2 = Pitch
             * 3 = Yaw
             */
            return new Eng_Matrix4x4(
                
                1 - 2 * (Math.Pow(Q.y, 2) + Math.Pow(Q.z, 2)),  // m11
                2 * (Q.x * Q.y - Q.w * Q.z),                    // m12
                2 * (Q.x * Q.z + Q.w * Q.y),                    // m13
                0, 

                // m21, m22, m23, 0
                2 * (Q.x * Q.y + Q.w * Q.z),                    // m21
                1 - 2 * (Math.Pow(Q.x, 2) + Math.Pow(Q.z, 2)),  // m22
                2 * (Q.y * Q.z - Q.w * Q.x),                    // m23
                0,

                // m31, m32, m33, 0
                2 * (Q.x * Q.z - Q.w * Q.y),                    // m31
                2 * (Q.y * Q.z + Q.w * Q.x),                    // m32
                1 - 2 * (Math.Pow(Q.x, 2) + Math.Pow(Q.y, 2)),  // m33
                0, 
                
                // 0, 0, 0, 1
                0, 
                0, 
                0, 
                1);
        }

        public static Tuple<double, double, double> QuaternionToEuler(double qW, double qX, double qY, double qZ)
        {
            // Tuple<roll, pitch, yaw>
            return new Tuple<double, double, double>(
                Calculator.RadiansToDegrees(Math.Atan((2 * (qX * qY + qW * qZ)) / (1 - 2 * (Math.Pow(qX, 2) + Math.Pow(qZ, 2))))),  // Roll
                Calculator.RadiansToDegrees(Math.Asin(-2 * (qY * qZ - qW * qX))),                                                   // Pitch
                Calculator.RadiansToDegrees(Math.Atan((2 * (qX * qZ + qW * qY)) / (1 - 2 * (Math.Pow(qX, 2) + Math.Pow(qY, 2)))))); // Yaw
        }

        // Extra Method
        public static Eng_Vector4D Rotation_Rotate3D(Eng_Vector4D v, Eng_Quaternion q)
        {
            /*
             * Find Rotation Matrix for Roll
             * Find Rotation Matrix for Pitch
             * Find Rotation Matrix for Yaw
             * 
             * Rotation Matrix for Pitch multiplied by the Rotation Matrix for Yaw
             * 
             * Rotation Matrix for Roll multiplied by the result of the above Multiplication
             * 
             * This gives our full Rotation Matrix
             * 
             * We multiply the Full Rotation Matrix by the Vector4D
             */
            return Calculator.Vector4D_MultiplyVector4DAnd4x4Matrix(v, Calculator.QuaternionToMatrix(q));
        }

        #endregion
        #endregion

        #region Lab03
            #region Part 1 - Linear Motion
        public static Tuple<double, double, double, double> Calculate_FinalVelocity_Displacement(
             double Ax, double Ay, double ViX, double ViY, double Time)
        {
            return new Tuple<double, double, double, double>(ViX + (Ax * Time), 
                ViY + (Ay * Time), 
                (ViX * Time) + (0.5 * Ax * Time * Time), 
                (ViY * Time) + (0.5 * Ay * Time * Time));
        }

        /*Calculate the horizontal displacement of a projectile, its max height, and time of flight 
         * given gravity, non-zero launch angle, and platform height.*/
         public static Tuple<double, double, double> Calculate_HorDisplacement_MaxHeight_Time(
            double initialVelocity, double launchAngle, double launchHeight, double gravity)
        {
            // d = vf^2 - vi^2 / 2a
            double maxHeight = -(Math.Pow(Math.Sin(launchAngle * Math.PI / 180) * initialVelocity, 2)) / 
                (2 * gravity) + launchHeight;

            // t = (-vi +- sqrt(vi^2 - 4(1/2 A)(-D))) / (2 * (1/2 A))
            double timePlusQuadratic = (-(Math.Sin(launchAngle * Math.PI / 180) * initialVelocity) + Math.Sqrt((Math.Sin(launchAngle * Math.PI / 180) * initialVelocity) * (Math.Sin(launchAngle * Math.PI / 180) * initialVelocity) - 
                4*(1/2 * gravity) * -maxHeight)) / (2 * (gravity / 2));
            double timeMinusQuadratic = (-(Math.Sin(launchAngle * Math.PI / 180) * initialVelocity) - Math.Sqrt((Math.Sin(launchAngle * Math.PI / 180) * initialVelocity) * (Math.Sin(launchAngle * Math.PI / 180) * initialVelocity) - 
                4 * (1 / 2 * gravity) * -maxHeight)) / (2 * (gravity / 2));

            double time;

            // picks the time value that's above 0
            if (timePlusQuadratic >= 0)
            {
                time = timePlusQuadratic;
            }
             else
            {
                time = timeMinusQuadratic;
            }

            double horizontalDisplacement = (Math.Cos(launchAngle * Math.PI / 180) * initialVelocity) * time;

            return new Tuple<double, double, double>(horizontalDisplacement, maxHeight, time);
        }
        #endregion

            #region Part 2 - Rotational Motion
        public static Tuple<double,double> Calculate_Omega_Acceleration(double RPM, double Radius)
        {
            return new Tuple<double, double>((RPM / 60) * 2 * Math.PI, Radius * (Math.Pow(((RPM / 60) * 2 * Math.PI),2)));
        }

        public static Tuple<double, double, double, double, double> Calculate_Theta_Omega_Alpha_TanVelocity(double ArcLength, double Radius, double Time)
        {
            return new Tuple<double, double, double, double, double>(
                ArcLength / Radius,
                (ArcLength / Radius) * 180 / Math.PI,
                (ArcLength / Radius) / Time, 
                ((ArcLength / Radius) / Time) / Time, 
                Radius * (((ArcLength / Radius) / Time) / Time));
        }

        public static Tuple<double, double> Calculate_TanVelocity_TanVelocity(double Omega, double RadiusA, double RadiusB)
        {
            return new Tuple<double, double>(RadiusA * (RadiusA * Omega * Omega),
                RadiusB * (RadiusB * Omega * Omega));
        }
        #endregion

            #region Part 3 - Forces
        public static Tuple<Eng_Vector2D, Eng_Vector2D, Eng_Vector2D, Eng_Vector2D>
            Calculate_NetForce_Acceleration(double gravityX, double gravityY, double mass, double force, double forceAngle, double mu, double inclineDegrees, double time)
        {
            // Math.Abs(value) * -1 
            // ensures that the value will always be negative
            double netForceY = (Math.Abs(
                (Math.Abs(mass * gravityY) * -1) * Math.Cos(inclineDegrees * Math.PI / 180)) * -1) + 
                (force * Math.Sin(forceAngle * Math.PI / 180)) + 
                Math.Abs((Math.Abs((Math.Abs(mass * gravityY) * -1) * Math.Cos(inclineDegrees * Math.PI / 180)) * -1) + 
                (force * Math.Sin(forceAngle * Math.PI / 180)));

            double netForceX = (Math.Abs(
                (Math.Abs(mass * gravityY) * -1) * Math.Sin(inclineDegrees * Math.PI / 180)) * -1) 
                + (force * Math.Cos(forceAngle * Math.PI / 180)) + 
                (Math.Abs(mu * Math.Abs((Math.Abs((Math.Abs(mass * gravityY) * -1) * Math.Cos(inclineDegrees * Math.PI / 180)) * -1) + 
                (force * Math.Sin(forceAngle * Math.PI / 180)))) * -1);

            double accelerationX = netForceX / mass;
            double accelerationY = netForceY / mass;

            double finalVelocityX = accelerationX * time;
            double finalVelocityY = accelerationY * time;

            double distanceX = 0.5 * accelerationX * time * time;
            double distanceY = 0.5 * accelerationY * time * time;

            return new Tuple<Eng_Vector2D, Eng_Vector2D, Eng_Vector2D, Eng_Vector2D>(
                new Eng_Vector2D(netForceX, netForceY), new Eng_Vector2D(accelerationX, accelerationY), new Eng_Vector2D(finalVelocityX, finalVelocityY), new Eng_Vector2D(distanceX, distanceY));
        }
        #endregion

            #region Part 4 - Gravitational Forces
        public static double Calculate_Gravity(double mass, double radius)
        {
            // Forces gravity to be a negative acceleration
            return Math.Abs((G * mass) / (radius * radius)) * -1;
        }


        public static double Calculate_GravitationalForce(double mass1, double mass2, double centerDistance)
        {
            return G * ((mass1 * mass2) / (centerDistance * centerDistance));
        }
            #endregion

            #region Part 5 - Springs
        public static double Calculate_SpringConstant(double stretchedDistance, double mass, double gravity)
        {
            return Math.Abs(mass * gravity) / stretchedDistance;
        }

        public static Tuple<double, double> Calculate_SpringOscillation_Velocity(double k, double mass, double stretchedDistance)
        {
            return new Tuple<double, double>((1 / (2 * Math.PI)) * (Math.Sqrt(k / mass)),
                stretchedDistance * ((1 / (2 * Math.PI)) * (Math.Sqrt(k / mass)) * 2 * Math.PI));
        }

            #endregion

            #region Part 6 - Impulse, Momentum & Collisions
        public static Tuple<double, double> Calculate_Momentum_StopTime(double initialVelocity, double mass, double brakingForce)
        {
            return new Tuple<double, double>(mass * initialVelocity,
            (mass * initialVelocity) / brakingForce);
        }

        //b.	Calculate the final velocities of two circular objects after a perfectly elastic collision.
        public static Tuple<double, double, double, double> Calculate_CircleCollision_FinalVelocities(double aX, double aY, double rA, double mA, double aViX, double aViY,
            double bX, double bY, double rB, double mB, double bViX, double bViY)
        {
            Eng_Vector2D normalizedNormal = Calculator.Vector2D_NormalizeVector(new Eng_Vector2D(aX - bX, aY - bY));

            // Optimized = (2(a1 - a2)) / (mA + mB)
            // a1 = Vai DOTPRODUCT normalizedN
            // a2 = Vbi DOTPRODUCT normalizedN
            double optimized = (2 * (
                /*a1*/Calculator.Vector2D_CalculateDotProduct(new Eng_Vector2D(aViX, aViY), normalizedNormal) - 
                /*a2*/Calculator.Vector2D_CalculateDotProduct(new Eng_Vector2D(bViX, bViY), normalizedNormal))) 
                / (mA + mB);

            return new Tuple<double, double, double, double>(
                /*VfaX*/aViX - (optimized * mB) * (normalizedNormal.X),
                /*VfaY*/aViY - (optimized * mB) * (normalizedNormal.Y),
                /*VfbX*/bViX + (optimized * mA) * (normalizedNormal.X),
                /*VfbY*/bViY + (optimized * mA) * (normalizedNormal.Y));
        }

        public static Tuple<double, double, double, double, double, double> Calculate_SphereCollision_FinalVelocities(double aX, double aY, double aZ, double rA, double mA, double aViX, double aViY, double aViZ,
            double bX, double bY, double bZ, double rB, double mB, double bViX, double bViY, double bViZ)
        {
            Eng_Vector3D normalizedNormal = Calculator.Vector3D_NormalizeVector(new Eng_Vector3D(aX - bX, aY - bY, aZ - bZ));

            // Optimized = (2(a1 - a2)) / (mA + mB)
            // a1 = Vai DOTPRODUCT normalizedN
            // a2 = Vbi DOTPRODUCT normalizedN
            double optimized = (2 * (
                /*a1*/Calculator.Vector3D_CalculateDotProduct(new Eng_Vector3D(aViX, aViY, aViZ), normalizedNormal) -
                /*a2*/Calculator.Vector3D_CalculateDotProduct(new Eng_Vector3D(bViX, bViY, bViZ), normalizedNormal))) 
                / (mA + mB);

            return new Tuple<double, double, double, double, double, double>(
                /*VfaX*/aViX - (optimized * mB) * (normalizedNormal.X),
                /*VfaY*/aViY - (optimized * mB) * (normalizedNormal.Y),
                /*VfaZ*/aViZ - (optimized * mB) * (normalizedNormal.Z),
                /*VfbX*/bViX + (optimized * mA) * (normalizedNormal.X),
                /*VfbY*/bViY + (optimized * mA) * (normalizedNormal.Y),
                /*VfbZ*/bViZ + (optimized * mA) * (normalizedNormal.Z));
        }
		#endregion
		#endregion

		#region ProjectileSimulationProject

		public static double Convert_Celsius_to_Kelvin(double Celsius)
		{
			return Celsius * 274.15;
		}

        public static Eng_Vector2D Calculate_Velocity_ByImpulse(double Mass , Eng_Vector2D ForceAplied, double Time, Eng_Vector2D InitialVelocity)
        {
            return new Eng_Vector2D(((ForceAplied.X * Time) / Mass) + InitialVelocity.X, ((ForceAplied.Y * Time) / Mass) + InitialVelocity.Y);
        }
		#endregion
	}
}
