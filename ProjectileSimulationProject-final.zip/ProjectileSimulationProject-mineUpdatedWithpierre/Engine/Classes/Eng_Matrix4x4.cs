﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 4x4  M
    /// </summary>
    public class Eng_Matrix4x4
    {
        public double m11 { get; set; }
        public double m12 { get; set; }
        public double m13 { get; set; }
        public double m14 { get; set; }

        public double m21 { get; set; }
        public double m22 { get; set; }
        public double m23 { get; set; }
        public double m24 { get; set; }

        public double m31 { get; set; }
        public double m32 { get; set; }
        public double m33 { get; set; }
        public double m34 { get; set; }

        public double m41 { get; set; }
        public double m42 { get; set; }
        public double m43 { get; set; }
        public double m44 { get; set; }


        public Eng_Matrix4x4() { }

        public Eng_Matrix4x4(double M11, double M12, double M13, double M14,
            double M21, double M22, double M23, double M24,
            double M31, double M32, double M33, double M34,
            double M41, double M42, double M43, double M44)
        {

            m11 = M11;
            m12 = M12;
            m13 = M13;
            m14 = M14;

            m21 = M21;
            m22 = M22;
            m23 = M23;
            m24 = M24;

            m31 = M31;
            m32 = M32;
            m33 = M33;
            m34 = M34;

            m41 = M41;
            m42 = M42;
            m43 = M43;
            m44 = M44;
        }


    }
}
