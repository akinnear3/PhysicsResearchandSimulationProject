﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a Quaternion using z-axis heading
    /// </summary>
    public class Eng_Quaternion
    {
        public double cR { get; set; }
        public double cP { get; set; }
        public double cY { get; set; }
        public double sR { get; set; }
        public double sP { get; set; }
        public double sY { get; set; }

        public double w { get; set; }
        public double z { get; set; }
        public double y { get; set; }
        public double x { get; set; }


        public Eng_Quaternion() { }

        public Eng_Quaternion(double Roll, double Pitch, double Yaw)
        {
            Roll = ConvertEulerDegreesToEulerRadians(Roll);
            Pitch = ConvertEulerDegreesToEulerRadians(Pitch);
            Yaw = ConvertEulerDegreesToEulerRadians(Yaw);

            SetShortcutValues(Roll, Pitch, Yaw);

            w = (cY * cP * cR) + (sY * sP * sR);
            x = (cY * sP * cR) + (sY * cP * sR);
            y = (sY * cP * cR) - (cY * sP * sR);
            z = (cY * cP * sR) - (sY * sP * cR);
        }

        private double ConvertEulerDegreesToEulerRadians(double eulerDegrees)
        {
            double eulerRadians;
            return eulerRadians = Calculator.DegreesToRadians(eulerDegrees);
        }
        private void SetShortcutValues(double Roll, double Pitch, double Yaw)
        {
            // These all work with radians
            cR = Math.Cos(Roll / 2);
            sR = Math.Sin(Roll / 2);

            cP = Math.Cos(Pitch / 2);
            sP = Math.Sin(Pitch / 2);

            cY = Math.Cos(Yaw / 2);
            sY = Math.Sin(Yaw / 2);

        }
    }
}
