﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Classes;
using Xunit;

namespace Engine.Specs
{
    public class Lab3Tester
    {
        #region Linear Motion
        [Theory]
        // Instructor Data
        [InlineData(3, -2, 0, -9.81, 2.5, 3, -26.525, 7.5, -35.6562)]
        // Student Data
        [InlineData(4, 5, 0, -9.81, 4, 4, -34.24, 16, -58.48)]
        public static void TestCalculateVelcityDisplacement(
            double vIx, double vIy, double gX, double gY, double t,
            double vFx, double vFy, double dX, double dY)
        {
            // Arrange - get data to do the test
           
            // Act - performing the action
            
            // Assert - did we get back the correct answers
           
        }

        [Theory]
        // Instructor Data
        [InlineData(2.5, 5, 15, -9.81, 4.4109, 15.0024, 1.7711)]
        // Student Data
        [InlineData(5, 20, 40, -9.81, 376.6961, 40.1491, 80.1743)]
        public static void TestCalculateProjectile(
            double vI, double degrees, double h, double g,
            double distance, double maxHeight, double t)
        {
            // Arrange - get data to do the test
            
            // Act - performing the action
            
            // Assert - did we get back the correct answers
           
        }
        #endregion

        #region Rotational Motion
        [Theory]
        // Instructor Data
        [InlineData(3200, 0.25, 335.1032, 28073.5414)]
        // Student Data
        [InlineData(5200, 2, 544.5427, 593053.5622)]
        public void TestRotationalMotion1(
            double rpm, double radius, double omega, double aT_Expected)
        {
            // Arrange - get data to do the test

            // Act - performing the action
           
            // Assert - did we get back the correct answers
            
        }

        [Theory]
        // Instructor Data
        [InlineData(0.25, 0.4, 2, 0.625, 35.8099, 0.3125, 0.1562, 0.125)]
        // Student Data
        [InlineData(1, 5, 10, 0.2, 11.4592, 0.02, 0.002, 0.02)]
        public static void TestRotationalMotion2(
            double arc, double radius, double t,
            double thetaR, double thetaD, double omega, double alpha, double vT)
        {
            // Arrange - get data to do the test

            // Act - performing the action
           
            // Assert - did we get back the correct answers
            
        }

        [Theory]
        // Instructor Data
        [InlineData(0.5, 0.25, 0.35, 0.125, 0.175)]
        // Student Data
        [InlineData(1.5, 3, 4, 4.5, 6)]
        public static void TestRotaionalMotion3(
            double omega, double aRadius, double bRadius,
            double vTa, double vTb)
        {
            // Arrange - get data to do the test

            // Act - performing the action
           
            // Assert - did we get back the correct answers
            
        }
        #endregion

        #region Forces
        [Theory]
        // Instructor Data
        [InlineData(0, -9.81, 100, 500, 10, 0.15, 0, 358.2775, 0, 3.5828, 0, 1.5, 5.3742, 0, 4.0306, 0)]// non-incline
        [InlineData(0, -9.81, 100, 500, 0, 0.15, 10, 184.7367, 0, 1.8474, 0, 1.5, 2.7711, 0, 2.0783, 0)]// incline
        // Student Data (two sets of data)
        [InlineData(0, -9.81, 25, 400, 30, 0.1, 0, 341.8852, 0, 13.6754, 0, 2, 27.3508, 0, 27.3508, 0)]// non-incline
        [InlineData(0, -9.81, 25, 400, 0, 0.1, 20, 293.0736, 0, 11.7229, 0, 2, 23.4459, 0, 23.4459, 0)]// incline

        public static void TestCalculateNetForce(
            double gX, double gY, double mass, double force, double forceAngle,
            double mu, double inclineDegrees, double netFx, double netFy,
            double aX, double aY, double t, double vFx, double vFy,
            double dX, double dY)
        {
            // Act - performing the action
            Tuple<Eng_Vector2D, Eng_Vector2D, Eng_Vector2D, Eng_Vector2D> results = Calculator.Calculate_NetForce_Acceleration(gX, gY, mass, force, forceAngle, mu, inclineDegrees, t);

            // Assert - did we get back the correct answers
            Assert.Equal(netFx, Math.Round(results.Item1.X, 4));
            Assert.Equal(netFy, Math.Round(results.Item1.Y, 4));
            Assert.Equal(aX, Math.Round(results.Item2.X, 4));
            Assert.Equal(aY, Math.Round(results.Item2.Y, 4));
            Assert.Equal(vFx, Math.Round(results.Item3.X, 4));
            Assert.Equal(vFy, Math.Round(results.Item3.Y, 4));
            Assert.Equal(dX, Math.Round(results.Item4.X, 4));
            Assert.Equal(dY, Math.Round(results.Item4.Y, 4));
        }
        #endregion

        #region Gravitational Forces
        [Theory]
        // Instructor Data
        [InlineData(450000, 9500000000, 25000, 0.0004564332)]
        // Student Data
        [InlineData(600000, 1000000, 30000, 4.45e-8)]
        public static void TestCalculateGravitationalForce(
            double mass1, double mass2, double centersDistance,
            double expected)
        {
            // Act - performing the action
            double results = Calculator.Calculate_GravitationalForce(mass1, mass2, centersDistance);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, Math.Round(results, 10));
        }

        [Theory]
        // Instructor Data
        [InlineData(3.5e24, 5e6, -9.3422)]
        // Student Data
        [InlineData(6.2e18, 3e4, -0.4597)]
        public static void TestCalculateGravity(double mass, double radius, double expected)
        {
            // Act - performing the action
            double results = Calculator.Calculate_Gravity(mass, radius);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, Math.Round(results, 4));
        }
        #endregion

        #region Springs
        [Theory]
        // Instructor Data
        [InlineData(0.3, 0.75, -9.81, 24.525)]
        // Student Data
        [InlineData(0.5, 2, -9.81, 39.24)]
        public static void TestCalculateSpringConstant(
            double stretchedLength, double mass, double gravity, double expected)
        {
            // Act - performing the action
            double results = Calculator.Calculate_SpringConstant(stretchedLength, mass, gravity);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, Math.Round(results, 3));
        }

        [Theory]
        // Instructor Data
        [InlineData(24.525, 0.75, 0.3, 0.9101, 1.7155)]
        // Student Data
        [InlineData(16.25, 1, 0.8, 0.6416, 3.2249)]
        public static void TestCalculateSpringFreqVelocity(
            double k, double mass, double stretchedLength, double expectedFreq, double expectedVelocity)
        {
            // Act - performing the action
            Tuple<double, double> results = Calculator.Calculate_SpringOscillation_Velocity(k, mass, stretchedLength);
            // Assert - did we get back the correct answers
            Assert.Equal(expectedFreq, Math.Round(results.Item1, 4));
            Assert.Equal(expectedVelocity, Math.Round(results.Item2, 4));
        }
        #endregion

        #region Impulse and Momentum
        [Theory]
        // Instructor Data
        [InlineData(5, 1025, 105, 5125, 48.8095)]
        // Student Data
        [InlineData(5, 1025, 105, 5125, 48.8095)]
        public static void TestCalculateMomentum(
            double vI, double mass, double brakingForce, double p, double t)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            Tuple<double,double> results = Calculator.Calculate_Momentum_StopTime(vI, mass, brakingForce);
            // Assert - did we get back the correct answers
            Assert.Equal(p, Math.Round(results.Item1, 4));
            Assert.Equal(t, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, -2, 1.5, 10, 1, 2, 
                    4, -1, 2.5, 5, -2, -1, 
                    -1, 0, 2, 3)]
        // Student Data
        [InlineData(2, 3, 2.5, 100, 5, 9,
                    5, -10, 5.3, 20, -9, -5, 
                    6, 6, -13, 12)]
        public static void TestCircleCollision(
            double aX, double aY, double aR, double aMass, double aViX, double aViY,
            double bX, double bY, double bR, double bMass, double bViX, double bViY,
            double aVfX, double aVfY, double bVfX, double bVfY)
        {
            // Act - performing the action
            Tuple<double, double, double, double> results = Calculator.Calculate_CircleCollision_FinalVelocities(
                aX,aY, aR, aMass, aViX, aViY, bX, bY, bR, bMass, bViX, bViY);
            // Assert - did we get back the correct answers
            Assert.Equal(aVfX, Math.Round(results.Item1));
            Assert.Equal(aVfY, Math.Round(results.Item2));
            Assert.Equal(bVfX, Math.Round(results.Item3));
            Assert.Equal(bVfY, Math.Round(results.Item4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, -2, 4, 1.5, 10, 1, 2, 2, 4, -1, -2, 2.5, 5, -2, -1, 2, 0.8947, 1.8947, 2.6316, -1.7895, -0.7895, 0.7368)]
        // Student Data
        [InlineData(5, 6, 4, 10, 20, 3, 2, 1,
                    8, -6, 7, 10, 10, -1, -2, -3, 
                    3.2963, 0.8148, 1.2963, -1.5926, 0.3704, -3.5926)]
        public static void TestSphereCollision(
            double aX, double aY, double aZ, double aR, double aMass, double aViX, double aViY, double aViZ,
            double bX, double bY, double bZ, double bR, double bMass, double bViX, double bViY, double bViZ,
            double aVfX, double aVfY, double aVfZ, double bVfX, double bVfY, double bVfZ)
        {
            // Act - performing the action
            Tuple<double, double, double, double, double, double> results = Calculator.Calculate_SphereCollision_FinalVelocities(
                aX, aY, aZ, aR, aMass, aViX, aViY, aViZ, bX, bY, bZ, bR, bMass, bViX, bViY, bViZ);
            // Assert - did we get back the correct answers
            Assert.Equal(aVfX, Math.Round(results.Item1, 4));
            Assert.Equal(aVfY, Math.Round(results.Item2, 4));
            Assert.Equal(aVfZ, Math.Round(results.Item3, 4));

            Assert.Equal(bVfX, Math.Round(results.Item4, 4));
            Assert.Equal(bVfY, Math.Round(results.Item5, 4));
            Assert.Equal(bVfZ, Math.Round(results.Item6, 4));
        }
        #endregion
    }
}
