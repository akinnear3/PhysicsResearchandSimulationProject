﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 2D Vector in component form
    /// </summary>
    public class Eng_Vector2D
    {
        public double X { get; set;}
        public double Y { get; set;}
        public double magnitude;
		public double angle;

        public Eng_Vector2D() { }

        public Eng_Vector2D(double VectorX , double VectorY)
        {
            X = VectorX;
            Y = VectorY;

            // Calculate the magnitude of this vector
            magnitude = CalculatedMagnitude();
			angle = CalculatedAngle();
        }

        private double CalculatedMagnitude()
        {
            return Math.Sqrt(Math.Pow(X,2) + Math.Pow(Y,2));
        }

		private double CalculatedAngle()
		{
			// SOH   Sin() = Y / Mag
			// CAH	 Cos() = X / Mag
			// TOA	 Tan() = Y / X;
			return Math.Tan(Y / X);
		}
    }
}
