﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 3D component vector in 4D homogeneous space
    /// </summary>
    public class Eng_Vector4D
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
        public double W { get; } = 1;

        public Eng_Vector4D() { }

        public Eng_Vector4D(double VectorX, double VectorY, double VectorZ, double VectorW)
        {
            X = VectorX;
            Y = VectorY;
            Z = VectorZ;
            W = VectorW;
        }
    }
}
