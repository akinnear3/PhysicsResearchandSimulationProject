﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using Microsoft.Xna.Framework;
using Engine;
using Engine.Classes;

namespace ProjectileSimulationProject
{
    public class Torque
    {
        #region torque
        /// <summary>
        /// Takes a foce, the angle to the surface, distance to the axis of rotation 
        /// and calculates Torque.
        /// </summary>
        /// <param name="Force"></param>
        /// <param name="angle">in degrees</param>
        /// <param name="distanceToAxis"></param>
        /// <returns></returns>

        public static double CalculateTorque(Eng_Vector2D Force, double angle, double distanceToAxis)
        {
            double Torque = Force.GetMagnitude() * Math.Sin(Calculator.DegreeToRadians(angle)) * distanceToAxis;
            return Torque;
        }
        public static double SumOfTorque(List<double> appliedTorques)
        {
            double TotalTorque = 0;
            foreach (double torque in appliedTorques)
            {
                TotalTorque += torque;
            }
            return TotalTorque;
        }
        #endregion
        #region Moment of Inertia
        public static double CalculateMomentOfInertia_PerfectSphere(double mass, double radius)
        {
            return 2 * mass * radius * radius / 5;
        }
        public static double CalculataMomentOfInertia_PointObject(double mass, double distanceFromAxisOfRotation)
        {
            return mass * distanceFromAxisOfRotation * distanceFromAxisOfRotation;
        }
        public static double CalculataMomentOfInertia_PointObject(List<double> mass, List<double> distanceFromAxisOfRotation)
        {
            if (mass.Count() != distanceFromAxisOfRotation.Count())
            {
                throw new Exception("number of items in 'mass' must equal the number of items in 'distanceFromAxisOfRotation'");
            }
            double Inertia = 0;
            for (int index = 0; index < mass.Count(); index++)
            {
                Inertia += mass[index] * distanceFromAxisOfRotation[index] * distanceFromAxisOfRotation[index];
            }
            return Inertia;
        }

        #endregion
        public static double CalculateAngularAcceleration(double SumOfTorque, double momentOfInertia)
        {
            return SumOfTorque / momentOfInertia;
        }
        public static double CalculateAngularVelocity(double AngularAcceleraion, GameTime time)
        {
            return AngularAcceleraion * time.ElapsedGameTime.TotalSeconds;
        }
        public static double CalculateRPS(double AngularVelocity)
        {
            return AngularVelocity / (2 * Math.PI);
        }
        
    }
}
