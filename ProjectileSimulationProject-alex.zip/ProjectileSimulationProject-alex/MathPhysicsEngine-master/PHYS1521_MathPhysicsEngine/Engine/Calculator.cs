﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Classes;

namespace Engine
{
    /// <summary>
    /// This class contains static methods to perform the math calculations.
    /// </summary>
    public class Calculator
    {
        //the gravitational constant
        public const double G = 6.673e-11;
        #region pre built methods 
        /// <summary>
        /// Calculates the length of a line segment between two 2D points.
        /// </summary>
        /// <param name="a">Eng_Point2D: a 2D point A</param>
        /// <param name="b">Eng_Point2D: a 2D point B</param>
        /// <returns>Double: length of the line segment.</returns>
        public static double SegmentLength(Eng_Point2D a, Eng_Point2D b)
        {
            return Math.Sqrt(Math.Pow(b.x - a.x, 2) + Math.Pow(b.y - a.y, 2));
        }

        /// <summary>
        /// Calculates the midpoint of the line segment between two 2D points.
        /// </summary>
        /// <param name="a">Eng_Point2D: a 2D point A</param>
        /// <param name="b">Eng_Point2D: a 2D point B</param>
        /// <returns>Eng_Point2D: midpoint on the line segemnt</returns>
        public static Eng_Point2D MidPoint(Eng_Point2D a, Eng_Point2D b)
        {
            return new Eng_Point2D(0.5 * (a.x + b.x), 0.5 * (a.y + b.y));
        }
        #endregion

        //my methods 
        #region Lab 01
        #region trig
        /// <summary>
        /// this method takes in the (double) degree and converts it to (double) radians 
        /// </summary>
        /// <param name="degree"></param>
        /// <returns>returns the radian value as a dooble (not rounded)</returns>
        public static double DegreeToRadians(double degree)
        {
            double radians = degree * Math.PI / 180;
            return radians;
        }

        /// <summary>
        /// takes in a radian of type double and converts it to a degree of type double (unrounded)
        /// </summary>
        /// <param name="radians"></param>
        /// <returns>unrounded (double) degree</returns>
        public static double RadiansToDegree(double radians)
        {
            double degree = radians * 180 / Math.PI;
            return degree;
        }

        //part 1, 1-c
        /// <summary>
        /// Part 1-c of Trig. takes in a hypotinuse and a degree
        /// </summary>
        /// <param name="hyp"></param>
        /// <param name="degree"></param>
        /// <returns>the adjacent (x) and the opposing (y)</returns>
        public static Tuple<double, double> SolveWithHypAndDegree(double hyp, double thetaR)
        {
            if (thetaR > 90 || thetaR < 0 || hyp < 0)
            {
                throw new Exception("IMput out of range. degree must be > 0 and < 90, and hypotinuse must be positive.");
            }
            double opp, adj;
            opp = hyp * Math.Sin(DegreeToRadians(thetaR));
            adj = hyp * Math.Cos(DegreeToRadians(thetaR));
            return new Tuple<double, double>(adj, opp);
        }

        //part 1, 1-d
        /// <summary>
        /// Part 1-d of Trig. Takes in the oppising and angle (in degrees) of a triangle.
        /// </summary>
        /// <param name="opp"></param>
        /// <param name="degree"></param>
        /// <returns>the adjacent (x) and the Hypotinuse</returns>
        public static Tuple<double, double> SolveWithOppAndDegree(double opp, double thetaR)
        {
            if (opp < 0 || thetaR < 0 || thetaR > 90)
            {
                throw new Exception("INput out of range. Opposing must be positive and the angle must be >0 and <90");
            }
            double hyp, adj;
            adj = Math.Abs(opp) / Math.Tan(DegreeToRadians(thetaR));
            hyp = Math.Abs(opp) / Math.Sin(DegreeToRadians(thetaR));
            return new Tuple<double, double>(adj, hyp);
        }

        //part 1, 1-e
        /// <summary>
        /// Part 1-e of Trig. takes in the adjacent and angle (in degrees) of a triangle.
        /// </summary>
        /// <param name="adj"></param>
        /// <param name="degree"></param>
        /// <returns>the opposing (y) and the Hypotinuse</returns>
        public static Tuple<double, double> SolveWithAdjAndDegree(double adj, double thetaR)
        {
            if (adj < 0 || thetaR < 0 || thetaR > 90)
            {
                throw new Exception("Input out of range. adjacent must be positive and angle must be >0 and <90");
            }
            double opp, hyp;
            opp = Math.Abs(adj) * Math.Tan(DegreeToRadians(thetaR));
            hyp = Math.Abs(adj) / Math.Cos(DegreeToRadians(thetaR));
            return new Tuple<double, double>(opp, hyp);
        }

        //part 1, 1-f
        /// <summary>
        /// Part 1-f of trig. Takes in the opposing and adjacent of a triangle.
        /// </summary>
        /// <param name="opp"></param>
        /// <param name="adj"></param>
        /// <returns>the Hypotinuse and angle (in degrees)</returns>
        public static Tuple<double, double> SolveWithOppAndAdj(double opp, double adj)
        {
            if (opp < 0 || adj < 0)
            {
                throw new Exception("Input out of range. Opposing must be positive and adjacent must be positive");
            }
            double hyp, thetaR;
            hyp = Math.Sqrt((opp * opp) + (adj * adj));
            thetaR = RadiansToDegree(Math.Atan(Math.Abs(opp / adj)));
            return new Tuple<double, double>(hyp, thetaR);
        }

        //part 1, 1-g
        /// <summary>
        /// Part 1-d of Trig. Takes in the opposing and Hypotinuse of a triangle.
        /// </summary>
        /// <param name="opp"></param>
        /// <param name="hyp"></param>
        /// <returns>the adjacent (x) and the angle (in degrees)</returns>
        public static Tuple<double, double> SolveWithOppAndHyp(double opp, double hyp)
        {
            double adj, thetaR;
            adj = Math.Sqrt((hyp * hyp) - (opp * opp));
            thetaR = RadiansToDegree(Math.Asin(Math.Abs(opp / hyp)));
            if (opp < 0 || hyp < opp)
            {
                throw new Exception("Input out of range. opposing must be positive and hypotinuse must be positive");
            }
            return new Tuple<double, double>(adj, thetaR);
        }

        //part 1, 1-h
        /// <summary>
        /// Part 1-h of Trig. Takes in the adjacent and hypotinuse of a triangle.
        /// </summary>
        /// <param name="adj"></param>
        /// <param name="hyp"></param>
        /// <returns>The opposing (y) and angle (in degrees)</returns>
        public static Tuple<double, double> SolveWithAdjAndHyp(double adj, double hyp)
        {
            double opp, thetaR;
            opp = Math.Sqrt((hyp * hyp) - (adj * adj));
            thetaR = RadiansToDegree(Math.Acos(Math.Abs(adj / hyp)));
            if (adj <= 0 || hyp < adj)
            {
                throw new Exception("Input out of range. Adjacent must be positive and hypotinuse must be positive");
            }
            return new Tuple<double, double>(opp, thetaR);
        }

        #endregion

        #region 2D Vectors
        /*
         * 
         *Vectors 2D 
         * 
         * 
         */

        /// <summary>
        /// takes 2 vectors, adds them, returns a new vector.
        /// </summary>
        /// <param name="Va"></param>
        /// <param name="Vb"></param>
        /// <returns></returns>
        public static Eng_Vector2D AddingVectors(Eng_Vector2D Va, Eng_Vector2D Vb)
        {
            double x, y;
            x = Va.X + Vb.X;
            y = Va.Y + Vb.Y;
            Eng_Vector2D result = new Eng_Vector2D(x, y);
            return result;
        }

        /// <summary>
        /// takes 2 vectors, solves for Dot Product, reurns a double
        /// </summary>
        /// <param name="Va"></param>
        /// <param name="Vb"></param>
        /// <returns></returns>
        public static double DotProduct2DVectors(Eng_Vector2D Va, Eng_Vector2D Vb)
        {
            double result = (Va.X * Vb.X) + (Va.Y * Vb.Y);
            return result;
        }

        /// <summary>
        /// takes in 2 2D vectors, converts it into an angle (into degrees), returns a double
        /// </summary>
        /// <param name="Va"></param>
        /// <param name="Vb"></param>
        /// <returns></returns>
        public static double AngleBetween2DVectors(Eng_Vector2D Va, Eng_Vector2D Vb)
        {
            double angle;
            angle = Math.Acos(DotProduct2DVectors(Va, Vb) / (Va.GetMagnitude() * Vb.GetMagnitude()));
            angle = RadiansToDegree(angle);
            return angle;
        }

        /// <summary>
        /// takes in a vector, normalizes it, returns a new vector
        /// </summary>
        /// <param name="Va"></param>
        /// <returns></returns>
        public static Eng_Vector2D normalize2DVector(Eng_Vector2D Va)
        {
            double x, y;
            x = Va.X / Va.GetMagnitude();
            y = Va.Y / Va.GetMagnitude();
            Eng_Vector2D Normalized = new Eng_Vector2D(x, y);
            return Normalized;
        }
        #endregion

        #region 3D vectors
        /*
         * 
         * Vectors 3D
         * 
         * 
         */

        //add 2 3d vectors
        /// <summary>
        /// takes in 2 3D vectors, add them, returns a new 3D vector
        /// </summary>
        /// <param name="Va"></param>
        /// <param name="Vb"></param>
        /// <returns></returns>
        public static Eng_Vector3D Add3DVector(Eng_Vector3D Va, Eng_Vector3D Vb)
        {
            double x, y, z;
            x = Va.X + Vb.X;
            y = Va.Y + Vb.Y;
            z = Va.Z + Vb.Z;
            return new Eng_Vector3D(x, y, z);
        }

        //Calculate the Dot Product of two 3D vectors
        /// <summary>
        /// takes in 2 3D vectors, calculates their Dot product, returns a double
        /// </summary>
        /// <param name="Va"></param>
        /// <param name="Vb"></param>
        /// <returns></returns>
        public static double DotProduct3DVector(Eng_Vector3D Va, Eng_Vector3D Vb)
        {
            double result = (Va.X * Vb.X) + (Va.Y * Vb.Y) + (Va.Z * Vb.Z);
            return result;
        }

        //Calculate the Cross Product of two 3D vectors
        /// <summary>
        /// takes in 2 3D vectors, calculates their Cross product, returns a new 3D vector
        /// </summary>
        /// <param name="Va"></param>
        /// <param name="Vb"></param>
        /// <returns></returns>
        public static Eng_Vector3D CrossProduct3DVector(Eng_Vector3D Va, Eng_Vector3D Vb)
        {
            double x, y, z;
            x = (Va.Y * Vb.Z) - (Va.Z * Vb.Y);
            y = (Va.Z * Vb.X) - (Va.X * Vb.Z);
            z = (Va.X * Vb.Y) - (Va.Y * Vb.X);
            return new Eng_Vector3D(x, y, z);
        }

        //Calculate the angle between two 3D vectors
        /// <summary>
        /// takes in 2 3D vectors, calculates their angle (in degrees), returns a double
        /// </summary>
        /// <param name="Va"></param>
        /// <param name="Vb"></param>
        /// <returns></returns>
        public static double Angle3DVector(Eng_Vector3D Va, Eng_Vector3D Vb)
        {
            double angle = Math.Acos(DotProduct3DVector(Va, Vb) / (Va.GetMagnitude() * Vb.GetMagnitude()));
            angle = RadiansToDegree(angle);
            return angle;
        }

        //Normalize a 3D vector
        /// <summary>
        /// Takes in 1 3D vector, Normalizes it, returns a new 3D vector
        /// </summary>
        /// <param name="Va"></param>
        /// <returns></returns>
        public static Eng_Vector3D Normalize3DVector(Eng_Vector3D Va)
        {
            double x, y, z;
            x = Va.X / Va.GetMagnitude();
            y = Va.Y / Va.GetMagnitude();
            z = Va.Z / Va.GetMagnitude();
            return new Eng_Vector3D(x, y, z);
        }

        /// <summary>
        /// takes 2 3Dvectors, first gets their cross product then normalizez it to obtain the surface normal, returs a new 3D vector
        /// </summary>
        /// <param name="Va"></param>
        /// <param name="Vb"></param>
        /// <returns></returns>
        public static Eng_Vector3D SurfaceNormal3DVector(Eng_Vector3D Va, Eng_Vector3D Vb)
        {
            Eng_Vector3D result = Calculator.CrossProduct3DVector(Va, Vb);
            result = Calculator.Normalize3DVector(result);
            return result;
        }
        #endregion
        #endregion
        #region Lab 02
        #region 2D Matrix transforms
        /// <summary>
        /// takes in a vector and a matrix, multiplies them, returns a 4D vector.
        /// </summary>
        /// <param name="Vector">Vector</param>
        /// <param name="Matrix">Matrix</param>
        /// <returns></returns>
        public static Eng_Vector4D MultiplyVectorBy4x4Matrix(Eng_Vector4D Vector, Eng_Matrix4x4 Matrix)
        {
            double x, y, z;
            x = Matrix.m11 * Vector.X + Matrix.m12 * Vector.Y + Matrix.m13 * Vector.Z + Matrix.m14 * Vector.W;
            y = Matrix.m21 * Vector.X + Matrix.m22 * Vector.Y + Matrix.m23 * Vector.Z + Matrix.m24 * Vector.W;
            z = Matrix.m31 * Vector.X + Matrix.m32 * Vector.Y + Matrix.m33 * Vector.Z + Matrix.m34 * Vector.W;
            return new Eng_Vector4D(x, y, z);
        }

        /// <summary>
        /// takes 2 4x4 Matrixes, multiplies them, returns a 4x4 matrix.
        /// </summary>
        /// <param name="MatrixA"></param>
        /// <param name="MatrixB"></param>
        /// <returns></returns>
        public static Eng_Matrix4x4 MultiplyMatrix4x4ByMatrix4x4(Eng_Matrix4x4 MatrixA, Eng_Matrix4x4 MatrixB)
        {
            double m11, m12, m13, m14, m21, m22, m23, m24, m31, m32, m33, m34, m41, m42, m43, m44;
            #region row 1
            m11 = MatrixA.m11 * MatrixB.m11 + MatrixA.m12 * MatrixB.m21 + MatrixA.m13 * MatrixB.m31 + MatrixA.m14 * MatrixB.m41;
            m12 = MatrixA.m11 * MatrixB.m12 + MatrixA.m12 * MatrixB.m22 + MatrixA.m13 * MatrixB.m32 + MatrixA.m14 * MatrixB.m42;
            m13 = MatrixA.m11 * MatrixB.m13 + MatrixA.m12 * MatrixB.m23 + MatrixA.m13 * MatrixB.m33 + MatrixA.m14 * MatrixB.m43;
            m14 = MatrixA.m11 * MatrixB.m14 + MatrixA.m12 * MatrixB.m24 + MatrixA.m13 * MatrixB.m34 + MatrixA.m14 * MatrixB.m44;
            #endregion
            #region row 2
            m21 = MatrixA.m21 * MatrixB.m11 + MatrixA.m22 * MatrixB.m21 + MatrixA.m23 * MatrixB.m31 + MatrixA.m24 * MatrixB.m41;
            m22 = MatrixA.m21 * MatrixB.m12 + MatrixA.m22 * MatrixB.m22 + MatrixA.m23 * MatrixB.m32 + MatrixA.m24 * MatrixB.m42;
            m23 = MatrixA.m21 * MatrixB.m13 + MatrixA.m22 * MatrixB.m23 + MatrixA.m23 * MatrixB.m33 + MatrixA.m24 * MatrixB.m43;
            m24 = MatrixA.m21 * MatrixB.m14 + MatrixA.m22 * MatrixB.m24 + MatrixA.m23 * MatrixB.m34 + MatrixA.m24 * MatrixB.m44;
            #endregion
            #region row 3
            m31 = MatrixA.m31 * MatrixB.m11 + MatrixA.m32 * MatrixB.m21 + MatrixA.m33 * MatrixB.m31 + MatrixA.m34 * MatrixB.m41;
            m32 = MatrixA.m31 * MatrixB.m12 + MatrixA.m32 * MatrixB.m22 + MatrixA.m33 * MatrixB.m32 + MatrixA.m34 * MatrixB.m42;
            m33 = MatrixA.m31 * MatrixB.m13 + MatrixA.m32 * MatrixB.m23 + MatrixA.m33 * MatrixB.m33 + MatrixA.m34 * MatrixB.m43;
            m34 = MatrixA.m31 * MatrixB.m14 + MatrixA.m32 * MatrixB.m24 + MatrixA.m33 * MatrixB.m34 + MatrixA.m34 * MatrixB.m44;
            #endregion
            #region row 4
            m41 = (MatrixA.m41 * MatrixB.m11) + (MatrixA.m42 * MatrixB.m21) + (MatrixA.m43 * MatrixB.m31) + (MatrixA.m44 * MatrixB.m41);
            m42 = MatrixA.m41 * MatrixB.m12 + MatrixA.m42 * MatrixB.m22 + MatrixA.m43 * MatrixB.m32 + MatrixA.m44 * MatrixB.m42;
            m43 = MatrixA.m41 * MatrixB.m13 + MatrixA.m42 * MatrixB.m23 + MatrixA.m43 * MatrixB.m33 + MatrixA.m44 * MatrixB.m43;
            m44 = MatrixA.m41 * MatrixB.m14 + MatrixA.m42 * MatrixB.m24 + MatrixA.m43 * MatrixB.m34 + MatrixA.m44 * MatrixB.m44;
            #endregion
            return new Eng_Matrix4x4(m11, m12, m13, m14, m21, m22, m23, m24, m31, m32, m33, m34, m41, m42, m43, m44);
        }

        /// <summary>
        /// takes in a 4x4 Matrix, transposes it, returns a 4x4 matrix.
        /// </summary>
        /// <param name="Matrix"></param>
        /// <returns></returns>
        public static Eng_Matrix4x4 TransposeA4x4Matrix(Eng_Matrix4x4 Matrix)
        {
            return new Eng_Matrix4x4(Matrix.m11, Matrix.m21, Matrix.m31, Matrix.m41,
                                     Matrix.m12, Matrix.m22, Matrix.m32, Matrix.m42,
                                     Matrix.m13, Matrix.m23, Matrix.m33, Matrix.m43,
                                     Matrix.m14, Matrix.m24, Matrix.m34, Matrix.m44);
        }

        /// <summary>
        /// Takes in a 4x4 matrix, calculates the determinant, returns a double.
        /// </summary>
        /// <param name="Matrix"></param>
        /// <returns></returns>
        public static double DeterminantOf4x4Matrix(Eng_Matrix4x4 Matrix)
        {
            return (Matrix.m11 * Matrix.m22 * Matrix.m33 * Matrix.m44
                  + Matrix.m12 * Matrix.m23 * Matrix.m34 * Matrix.m41
                  + Matrix.m13 * Matrix.m24 * Matrix.m31 * Matrix.m42
                  + Matrix.m14 * Matrix.m21 * Matrix.m32 * Matrix.m43
                  - Matrix.m14 * Matrix.m23 * Matrix.m32 * Matrix.m41
                  - Matrix.m13 * Matrix.m22 * Matrix.m31 * Matrix.m44
                  - Matrix.m12 * Matrix.m21 * Matrix.m34 * Matrix.m43
                  - Matrix.m11 * Matrix.m24 * Matrix.m33 * Matrix.m42);
        }

        public static Eng_Matrix4x4 InverseOf4x4Matrix(Eng_Matrix4x4 M)
        {
            double determinant = DeterminantOf4x4Matrix(M);
            double c11, c12, c13, c14,
                   c21, c22, c23, c24,
                   c31, c32, c33, c34,
                   c41, c42, c43, c44;
            #region row 1
            c11 = (M.m22 * M.m33 * M.m44
                 + M.m23 * M.m34 * M.m42
                 + M.m24 * M.m32 * M.m43
                 - M.m24 * M.m33 * M.m42
                 - M.m23 * M.m32 * M.m44
                 - M.m22 * M.m34 * M.m43)
                 * (1 / determinant);
            c12 = -1 * (M.m21 * M.m33 * M.m44
                 + M.m23 * M.m34 * M.m41
                 + M.m24 * M.m31 * M.m43
                 - M.m24 * M.m33 * M.m41
                 - M.m23 * M.m31 * M.m44
                 - M.m21 * M.m34 * M.m43)
                 * (1 / determinant);
            c13 = (M.m21 * M.m32 * M.m44
                 + M.m22 * M.m34 * M.m41
                 + M.m24 * M.m31 * M.m42
                 - M.m24 * M.m32 * M.m41
                 - M.m22 * M.m31 * M.m44
                 - M.m21 * M.m34 * M.m42)
                 * (1 / determinant);
            c14 = -1 * (M.m21 * M.m32 * M.m43
                 + M.m22 * M.m33 * M.m41
                 + M.m23 * M.m31 * M.m42
                 - M.m23 * M.m32 * M.m41
                 - M.m22 * M.m31 * M.m43
                 - M.m21 * M.m33 * M.m42)
                 * (1 / determinant);
            #endregion
            #region row 2
            c21 = -1 * (M.m12 * M.m33 * M.m44
                 + M.m13 * M.m34 * M.m42
                 + M.m14 * M.m32 * M.m43
                 - M.m14 * M.m33 * M.m42
                 - M.m13 * M.m32 * M.m44
                 - M.m12 * M.m34 * M.m43)
                 * (1 / determinant);
            c22 = (M.m11 * M.m33 * M.m44
                 + M.m13 * M.m34 * M.m41
                 + M.m14 * M.m31 * M.m43
                 - M.m14 * M.m33 * M.m41
                 - M.m13 * M.m31 * M.m44
                 - M.m11 * M.m34 * M.m43)
                 * (1 / determinant);
            c23 = -1 * (M.m11 * M.m32 * M.m44
                 + M.m12 * M.m34 * M.m41
                 + M.m14 * M.m31 * M.m42
                 - M.m14 * M.m32 * M.m41
                 - M.m12 * M.m31 * M.m44
                 - M.m11 * M.m34 * M.m42)
                 * (1 / determinant);
            c24 = (M.m11 * M.m32 * M.m43
                 + M.m12 * M.m33 * M.m41
                 + M.m13 * M.m31 * M.m42
                 - M.m13 * M.m32 * M.m41
                 - M.m12 * M.m31 * M.m43
                 - M.m11 * M.m33 * M.m42)
                 * (1 / determinant);
            #endregion
            #region row 3
            c31 = (M.m12 * M.m23 * M.m44
                 + M.m13 * M.m24 * M.m42
                 + M.m14 * M.m22 * M.m43
                 - M.m14 * M.m23 * M.m42
                 - M.m13 * M.m22 * M.m44
                 - M.m12 * M.m24 * M.m43)
                 * (1 / determinant);
            c32 = -1 * (M.m11 * M.m23 * M.m44
                 + M.m13 * M.m24 * M.m41
                 + M.m14 * M.m21 * M.m43
                 - M.m14 * M.m23 * M.m41
                 - M.m13 * M.m21 * M.m44
                 - M.m11 * M.m24 * M.m43)
                 * (1 / determinant);
            c33 = (M.m11 * M.m22 * M.m44
                 + M.m12 * M.m24 * M.m41
                 + M.m14 * M.m21 * M.m42
                 - M.m14 * M.m22 * M.m41
                 - M.m12 * M.m21 * M.m44
                 - M.m11 * M.m24 * M.m42)
                 * (1 / determinant);
            c34 = -1 * (M.m11 * M.m22 * M.m43
                 + M.m12 * M.m23 * M.m41
                 + M.m13 * M.m21 * M.m42
                 - M.m13 * M.m22 * M.m41
                 - M.m12 * M.m21 * M.m43
                 - M.m11 * M.m23 * M.m42)
                 * (1 / determinant);
            #endregion
            #region row 4
            c41 = -1 * (M.m12 * M.m23 * M.m34
                 + M.m13 * M.m24 * M.m32
                 + M.m14 * M.m22 * M.m33
                 - M.m14 * M.m23 * M.m32
                 - M.m13 * M.m22 * M.m34
                 - M.m12 * M.m24 * M.m33)
                 * (1 / determinant);
            c42 = (M.m11 * M.m23 * M.m34
                 + M.m13 * M.m24 * M.m31
                 + M.m14 * M.m21 * M.m33
                 - M.m14 * M.m23 * M.m31
                 - M.m13 * M.m21 * M.m34
                 - M.m11 * M.m24 * M.m33)
                 * (1 / determinant);
            c43 = -1 * (M.m11 * M.m22 * M.m34
                 + M.m12 * M.m24 * M.m31
                 + M.m14 * M.m21 * M.m32
                 - M.m14 * M.m22 * M.m31
                 - M.m12 * M.m21 * M.m34
                 - M.m11 * M.m24 * M.m32)
                 * (1 / determinant);
            c44 = (M.m11 * M.m22 * M.m33
                 + M.m12 * M.m23 * M.m31
                 + M.m13 * M.m21 * M.m32
                 - M.m13 * M.m22 * M.m31
                 - M.m12 * M.m21 * M.m33
                 - M.m11 * M.m23 * M.m32)
                 * (1 / determinant);
            #endregion

            return TransposeA4x4Matrix(new Eng_Matrix4x4(c11, c12, c13, c14, c21, c22, c23, c24, c31, c32, c33, c34, c41, c42, c43, c44));
        }
        #endregion

        #region 2D Rotation
        public static Eng_Vector3D Point2DRotationByAngle(Eng_Vector3D P, double Degrees)
        {
            double x, y, cos, sin;
            cos = Math.Cos(Calculator.DegreeToRadians(Degrees));
            sin = Math.Sin(Calculator.DegreeToRadians(Degrees));
            x = P.X * cos + P.Y * -1 * sin;
            y = P.X * sin + P.Y * cos;
            return new Eng_Vector3D(x, y, 1);
        }

        public static Eng_Vector3D Point2DRotationByMatrix(Eng_Vector3D P, Eng_Matrix3x3 M)
        {
            double x, y, z;
            x = P.X * M.m11 + P.Y * M.m12 + P.Z * M.m13;
            y = P.X * M.m21 + P.Y * M.m22 + P.Z * M.m23;
            z = P.X * M.m31 + P.Y * M.m32 + P.Z * M.m33;
            return new Eng_Vector3D(x, y, z);
        }

        #endregion

        #region 3D Rotation
        public static Eng_Matrix4x4 QuaternionToMatrix(Eng_Quaternion Q)
        {
            double c11, c12, c13, c14,
                   c21, c22, c23, c24,
                   c31, c32, c33, c34,
                   c41, c42, c43, c44;
            #region r1
            c11 = 1 - 2 * (Q.Y * Q.Y + Q.Z * Q.Z);
            c12 = 2 * (Q.X * Q.Y - Q.W * Q.Z);
            c13 = 2 * (Q.X * Q.Z + Q.W * Q.Y);
            c14 = 0;
            #endregion
            #region r2
            c21 = 2 * (Q.X * Q.Y + Q.W * Q.Z);
            c22 = 1 - 2 * (Q.X * Q.X + Q.Z * Q.Z);
            c23 = 2 * (Q.Y * Q.Z - Q.W * Q.X);
            c24 = 0;
            #endregion
            #region r3
            c31 = 2 * (Q.X * Q.Z - Q.W * Q.Y);
            c32 = 2 * (Q.Y * Q.Z + Q.W * Q.X);
            c33 = 1 - 2 * (Q.X * Q.X + Q.Y * Q.Y);
            c34 = 0;
            #endregion
            #region r4
            c41 = 0;
            c42 = 0;
            c43 = 0;
            c44 = 1;
            #endregion
            return new Eng_Matrix4x4(c11, c12, c13, c14,
                                     c21, c22, c23, c24,
                                     c31, c32, c33, c34,
                                     c41, c42, c43, c44);
        }

        public static Eng_Vector4D RotateVectorByQuaternion(Eng_Vector4D V, Eng_Quaternion Q)
        {
            //double VX = V.X * Q.W;
            //double VY = V.Y * Q.X;
            //double VZ = V.Z * Q.Y;
            //double VW = V.W * Q.Z;
            Eng_Matrix4x4 M = Calculator.QuaternionToMatrix(Q);
            double VX = V.X * M.m11 + V.Y * M.m12 + V.Z * M.m13 + V.W * M.m14;
            double VY = V.X * M.m21 + V.Y * M.m22 + V.Z * M.m23 + V.W * M.m24;
            double VZ = V.X * M.m31 + V.Y * M.m32 + V.Z * M.m33 + V.W * M.m34;
            double VW = V.X * M.m41 + V.Y * M.m42 + V.Z * M.m43 + V.W * M.m44;
            return new Eng_Vector4D(VX, VY, VZ, VW);
        }

        public static Tuple<double, double, double> QuaternionToEuler(Eng_Quaternion Q)
        {
            double Roll, Pitch, Yaw;
            Roll = Calculator.RadiansToDegree(Math.Atan(2 * (Q.X * Q.Y + Q.W * Q.Z) / (1 - 2 * (Q.X * Q.X + Q.Z * Q.Z))));
            Pitch = Calculator.RadiansToDegree(Math.Asin(-2 * (Q.Y * Q.Z - Q.W * Q.X)));
            Yaw = Calculator.RadiansToDegree(Math.Atan(2 * (Q.X * Q.Z + Q.W * Q.Y) / (1 - 2 * (Q.X * Q.X + Q.Y * Q.Y))));
            return new Tuple<double, double, double>(Roll, Pitch, Yaw);
        }

        #endregion
        #endregion
        #region Lab 03
        #region Linear Motion
        /// <summary>
        /// determins the final velocity and displacement of an object given acceleration, time and initial velocity.
        /// Item 1 is final velocity
        /// Item 2 is Displacement
        /// </summary>
        /// <param name="acceleration"></param>
        /// <param name="time"></param>
        /// <param name="initialVelocity"></param>
        /// <returns></returns>
        public static Tuple<Eng_Vector2D, Eng_Vector2D> getFinalVelocityandDisplacement(Eng_Vector2D acceleration, double time, Eng_Vector2D initialVelocity)
        {
            Eng_Vector2D finalVelocity, displacement;
            displacement = new Eng_Vector2D((initialVelocity.X * time) + (0.5 * acceleration.X * (time * time)), (initialVelocity.Y * time) + (0.5 * acceleration.Y * (time * time)));
            finalVelocity = new Eng_Vector2D((acceleration.X * time) + initialVelocity.X, (acceleration.Y * time) + initialVelocity.Y);

            return new Tuple<Eng_Vector2D, Eng_Vector2D>(finalVelocity, displacement); ;
        }
        /// <summary>
        /// Takes in the lauch angle (blows up if 0 for now), PlatformHeight, Initial projectile velocity, Gravity.
        /// </summary>
        /// <param name="Gravity"></param>
        /// <param name="Angle"></param>
        /// <param name="PlatformHeight"></param>
        /// <returns></returns>
        public static Tuple<double, double, double> getHorizontalDisplacementMaxHeightTime(double Gravity, double PlatformHeight, Eng_Vector2D InitialVelocity)
        {
            if(Gravity >= 0)
            {
                throw new Exception("Gravity must be negative to make the projectile fall");
            }
            double displacement, MaxHeight, time;
            time = (-InitialVelocity.Y - Math.Sqrt((InitialVelocity.Y * InitialVelocity.Y) - 2 * Gravity * PlatformHeight)) / Gravity;
            displacement = time * InitialVelocity.X;
            MaxHeight = PlatformHeight + (InitialVelocity.Y * (-InitialVelocity.Y/Gravity) + 0.5 * Gravity * Math.Pow((-InitialVelocity.Y/Gravity),2) );
            return new Tuple<double, double, double>(displacement, MaxHeight, time);
        }

        public static Tuple<double, double, double> getHorizontalDisplacementMaxHeightTime(double Gravity, double PlatformHeight, double InitialVelocityMag, double degrees)
        {
            Eng_Vector2D InitialVelocity = new Eng_Vector2D(InitialVelocityMag * Math.Cos(DegreeToRadians(degrees)), InitialVelocityMag * Math.Sin(DegreeToRadians(degrees)));
            if (Gravity >= 0)
            {
                throw new Exception("Gravity must be negative to make the projectile fall");
            }
            double displacement, MaxHeight, time;
            time = (-InitialVelocity.Y - Math.Sqrt((InitialVelocity.Y * InitialVelocity.Y) - 2 * Gravity * PlatformHeight))/Gravity;
            displacement = time * InitialVelocity.X;
            MaxHeight = PlatformHeight + (InitialVelocity.Y * (-InitialVelocity.Y / Gravity) + 0.5 * Gravity * Math.Pow((-InitialVelocity.Y / Gravity), 2));
            return new Tuple<double, double, double>(displacement, MaxHeight, time);
        }
        #endregion
        #region Rotational Motion
        /// <summary>
        /// calculates angular velocity and angular acceleration from RPM (rounds per minute) and radius.
        /// returs angular velocity then angular acceleration
        /// </summary>
        /// <param name="RPM"></param>
        /// <param name="radius"></param>
        /// <returns></returns>
        public static Tuple<double, double> getAngularVelocityAndAngularAcceleration(double RPM, double radius)
        {
            double angularVelocity, angularAcceleration;
            angularVelocity = RPM * (2* Math.PI) / 60;
            angularAcceleration =  radius * angularVelocity * angularVelocity;
            return new Tuple<double, double>(angularVelocity, angularAcceleration);
        }

        /// <summary>
        /// Calculates  AngularVelocity, AngularAcceleration, TangentalVelocity, and the angle in radians and degrees.
        /// takes in the arc Length of a circle its radiuce and how long it to to traverse the arc
        /// </summary>
        /// <param name="ArcLength"></param>
        /// <param name="radius"></param>
        /// <param name="time"></param>
        /// <returns></returns>
        public static Tuple<double, double, double, double, double> getAngle_AngularV_AngularA_TangentalV(double ArcLength, double radius, double time)
        {
            double radians, degrees, AngularVelocity, AngularAcceleration, TangentalVelocity;
            radians = ArcLength / radius;
            degrees = (ArcLength / radius) * 180 / Math.PI;
            AngularVelocity = radians / time;
            AngularAcceleration = ((ArcLength / radius) / time) / time ;
            TangentalVelocity =  radius * ((ArcLength / radius) / time);
            return new Tuple<double, double, double, double, double>(radians, degrees, AngularVelocity, AngularAcceleration, TangentalVelocity);
        }

        /// <summary>
        /// Takes in the Angular acceleration and the radius of two objects. 
        /// returns the Tangental velocity of a then Tangental velocity of b.
        /// </summary>
        /// <param name="AngularAcceleration"></param>
        /// <param name="radiusOfA"></param>
        /// <param name="radiusOfB"></param>
        /// <returns></returns>
        public static Tuple<double, double> getTangentalVelocityOfTwoObjects(double AngularAcceleration, double radiusOfA, double radiusOfB)
        {
            return new Tuple<double, double>(AngularAcceleration * radiusOfA, AngularAcceleration * radiusOfB);
        }
        #endregion
        #region Forces
        /// <summary>
        /// does calculations to get an Inclined plane.
        /// Note: External foce is relative to the plane.
        /// Note: returning Information Is still relative to the plane.
        /// </summary>
        /// <param name="ExternalForce"></param>
        /// <param name="angleOfIncline"></param>
        /// <param name="mass"></param>
        /// <param name="Gravity"></param>
        /// <param name="CoeficientOfFriction"></param>
        /// <returns></returns>
        public static Tuple<Eng_Vector2D, Eng_Vector2D, Eng_Vector2D, Eng_Vector2D> getNetForceAndAcceleration(Eng_Vector2D ExternalForce, double angleOfIncline, double mass, Eng_Vector2D Gravity, double CoeficientOfFriction, double time)
        {
            double ForcePerpendicular = Gravity.Y * mass * Math.Cos(DegreeToRadians(angleOfIncline));
            double ForceParalel = Gravity.Y * mass * Math.Sin(DegreeToRadians(angleOfIncline));
            if(Math.Abs(ForcePerpendicular) < Math.Abs(ExternalForce.Y))
            {
                throw new Exception("the Force applied should not exceed the force of gravity. Object is being carried.");
            }
            Eng_Vector2D ForceNormal = new Eng_Vector2D(0, Math.Abs(ForcePerpendicular) - ExternalForce.Y);
            Eng_Vector2D ForceOfFriction = new Eng_Vector2D(CoeficientOfFriction * ForceNormal.Y, 0);
            Eng_Vector2D ForceNet;
            ForceNet = new Eng_Vector2D(ExternalForce.X + ForceParalel, ExternalForce.Y + ForcePerpendicular + ForceNormal.Y);
            if(ForceNet.X > 0)
            {
                ForceNet = new Eng_Vector2D((ForceNet.X - ForceOfFriction.X) <=0 ? 0 : ForceNet.X - ForceOfFriction.X, ForceNet.Y - ForceOfFriction.Y);
            }
            else
            {
                ForceNet = new Eng_Vector2D((ForceNet.X + ForceOfFriction.X) >= 0 ? 0 : ForceNet.X + ForceOfFriction.X, ForceNet.Y - ForceOfFriction.Y);
            }
            Eng_Vector2D finalVelocity = new Eng_Vector2D(ForceNet.X * time / mass, ForceNet.Y * time / mass);
            Eng_Vector2D displacement = new Eng_Vector2D(0.5 * ForceNet.X / mass * time * time, 0.5 * ForceNet.Y / mass * time * time);
            return new Tuple<Eng_Vector2D, Eng_Vector2D, Eng_Vector2D, Eng_Vector2D>(ForceNet, new Eng_Vector2D(ForceNet.X / mass, ForceNet.Y / mass), displacement, finalVelocity);
        }

        #endregion
        #region Gravitational Forces
        public static double getForceOfGravity(double massOfA, double massOfB, double radius)
        {
            return  G * massOfA * massOfB / (radius * radius);
        }

        public static double getSurfaceAttraction(double mass, double raddius)
        {
            return -G * mass / (raddius * raddius);
        }
        #endregion
        #region springs
        public static double getSpringConstant(double forceReturn, double stretchLength)
        {
            return - forceReturn / stretchLength;
        }
        public static Tuple<double, double> getVelocityAndFrequencyAtEquilibreum(double mass, double SpringConstant, double stretchLength)
        {
            double Velocity = stretchLength * Math.Sqrt(SpringConstant / mass);
            double frequency = Math.Sqrt(SpringConstant / mass) / (2 * Math.PI);

            return new Tuple<double, double>(Velocity, frequency);

        }
        #endregion
        #region momentum and Impulse
        public static Tuple<Eng_Vector2D, double> getMomentumAndStopingTime(Eng_Vector2D velocity, double mass, double breakingForce)
        {
            Eng_Vector2D momentum = new Eng_Vector2D(velocity.X * mass, velocity.Y * mass);
            double stoppingTime = momentum.GetMagnitude() / breakingForce;

            return new Tuple<Eng_Vector2D, double>(momentum, stoppingTime);
        }

        public static Tuple<Eng_Vector2D, Eng_Vector2D> getFinalVelocitiesofTwoCirclesColliding(Eng_Circle circleA, Eng_Circle circleB)
        {
            Eng_Vector2D normal, normalizedNormal, finalVelocityA, finalVelocityB;
            double a1, a2, optimized;

            normal = new Eng_Vector2D(circleA.center.X - circleB.center.X, circleA.center.Y - circleB.center.Y);
            normalizedNormal = new Eng_Vector2D(normal.X / normal.GetMagnitude(), normal.Y / normal.GetMagnitude());
            a1 = normalizedNormal.X * circleA.velocity.X + normalizedNormal.Y * circleA.velocity.Y;
            a2 = normalizedNormal.X * circleB.velocity.X + normalizedNormal.Y * circleB.velocity.Y;
            optimized = 2 * (a1 - a2) / (circleA.mass + circleB.mass);

            finalVelocityA = new Eng_Vector2D(circleA.velocity.X - ((optimized * circleB.mass) * normalizedNormal.X), circleA.velocity.Y - ((optimized * circleB.mass) * normalizedNormal.Y));
            finalVelocityB = new Eng_Vector2D(circleB.velocity.X + ((optimized * circleA.mass) * normalizedNormal.X), circleB.velocity.Y + ((optimized * circleA.mass) * normalizedNormal.Y));
            return new Tuple<Eng_Vector2D, Eng_Vector2D>(finalVelocityA, finalVelocityB);
        }

        public static Tuple<Eng_Vector3D, Eng_Vector3D> getFinalVelocitiesofTwoSpheresColiding(Eng_Sphere sphereA, Eng_Sphere sphereB)
        {
            Eng_Vector3D normal, normalizedNormal, finalVelocityA, finalVelocityB;
            double a1, a2, optimized;

            normal = new Eng_Vector3D(sphereA.center.X - sphereB.center.X, sphereA.center.Y - sphereB.center.Y, sphereA.center.Z - sphereB.center.Z);
            normalizedNormal = new Eng_Vector3D(normal.X / normal.GetMagnitude(), normal.Y / normal.GetMagnitude(), normal.Z / normal.GetMagnitude());
            a1 = normalizedNormal.X * sphereA.velocity.X + normalizedNormal.Y * sphereA.velocity.Y + normalizedNormal.Z * sphereA.velocity.Z;
            a2 = normalizedNormal.X * sphereB.velocity.X + normalizedNormal.Y * sphereB.velocity.Y + normalizedNormal.Z * sphereB.velocity.Z;
            optimized = 2 * (a1 - a2) / (sphereA.mass + sphereB.mass);

            finalVelocityA = new Eng_Vector3D(sphereA.velocity.X - ((optimized * sphereB.mass) * normalizedNormal.X), sphereA.velocity.Y - ((optimized * sphereB.mass) * normalizedNormal.Y), sphereA.velocity.Z - ((optimized * sphereB.mass) * normalizedNormal.Z));
            finalVelocityB = new Eng_Vector3D(sphereB.velocity.X + ((optimized * sphereA.mass) * normalizedNormal.X), sphereB.velocity.Y + ((optimized * sphereA.mass) * normalizedNormal.Y), sphereB.velocity.Z + ((optimized * sphereA.mass) * normalizedNormal.Z));
            return new Tuple<Eng_Vector3D, Eng_Vector3D>(finalVelocityA, finalVelocityB);
        }
        #endregion


        #endregion
    }
}
