﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a Sphere for mathematical calculations.
    /// </summary>
    public class Eng_Sphere
    {
        public Eng_Vector3D center { get; private set; }
        public double radius { get; private set; }
        public double mass { get; private set; }
        public Eng_Vector3D velocity { get; set; }

        public Eng_Sphere(Eng_Vector3D Center, double Radius, double Mass)
        {
            center = Center;
            radius = Radius;
            mass = Mass;
        }
        public Eng_Sphere(Eng_Vector3D Center, double Radius, double Mass, Eng_Vector3D Velocity)
        {
            center = Center;
            radius = Radius;
            mass = Mass;
            velocity = Velocity;
        }
    }
}
