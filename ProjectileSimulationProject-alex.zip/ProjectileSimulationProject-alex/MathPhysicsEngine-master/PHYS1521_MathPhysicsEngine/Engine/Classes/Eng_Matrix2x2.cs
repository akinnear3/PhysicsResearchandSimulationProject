﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 2x2  matrix
    /// </summary>
    public class Eng_Matrix2x2
    {
        public double m11 { get; set; }
        public double m12 { get; set; }
        public double m21 { get; set; }
        public double m22 { get; set; }

        public Eng_Matrix2x2(double M11, double M12, double M21, double M22)
        {
            m11 = M11;
            m12 = M12;
            m21 = M21;
            m22 = M22;
        }

    }
}
