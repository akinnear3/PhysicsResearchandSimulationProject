﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 2D Vector in component form
    /// </summary>
    public class Eng_Vector2D
    {
        //properties
        public double X { get; set; }
        public double Y { get; set; }

        //constructor
        public Eng_Vector2D(double x, double y)
        {
            X = x;
            Y = y;
        }

        //methods
        public double GetMagnitude()
        {
            return Math.Sqrt((X * X) + (Y * Y));
        }

        public override string ToString()
        {
            return $"({X}, {Y})";
        }
    }
}
