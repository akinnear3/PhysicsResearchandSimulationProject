﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 2D vector with magnitude@direction
    /// </summary>
    public class Eng_PolarVector
    {
        public double magnitude { get; private set; }
        public double X { get; private set; }
        public double Y { get; private set; }

        /// <summary>
        /// takes a magnitude at a direction (angle in degrees) and makes a 2D vector
        /// </summary>
        /// <param name="Magnitude"></param>
        /// <param name="Direction"></param>
        public Eng_PolarVector(double Magnitude, double Direction)
        {
            X = Math.Cos(Magnitude * Calculator.DegreeToRadians(Direction));
            Y = Math.Sin(Magnitude * Calculator.DegreeToRadians(Direction));
        }

        public override string ToString()
        {
            return $"({X}, {Y})";
        }
    }
}
