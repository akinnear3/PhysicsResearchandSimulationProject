﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a Quaternion using z-axis heading
    /// </summary>
    public class Eng_Quaternion
    {
        //properties
        public double W { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }

        //constructors
        public Eng_Quaternion(double w, double x, double y, double z)
        {
            W = w;
            X = x;
            Y = y;
            Z = z;
        }
        public Eng_Quaternion(double Bank, double Attitude, double Heading)
        {
            double RollHalfCos = Math.Cos(Calculator.DegreeToRadians(Bank / 2));
            double RollHalfSin = Math.Sin(Calculator.DegreeToRadians(Bank / 2));
            double PitchHalfCos = Math.Cos(Calculator.DegreeToRadians(Attitude / 2));
            double PitchHalfSin = Math.Sin(Calculator.DegreeToRadians(Attitude / 2));
            double YawHalfCos = Math.Cos(Calculator.DegreeToRadians(Heading / 2));
            double YawHalfSin = Math.Sin(Calculator.DegreeToRadians(Heading / 2));

            W = YawHalfCos * PitchHalfCos * RollHalfCos
                + YawHalfSin * PitchHalfSin * RollHalfSin;

            X = YawHalfCos * PitchHalfSin * RollHalfCos
                + YawHalfSin * PitchHalfCos * RollHalfSin;

            Y = YawHalfSin * PitchHalfCos * RollHalfCos
                - YawHalfCos * PitchHalfSin * RollHalfSin;

            Z = YawHalfCos * PitchHalfCos * RollHalfSin
                - YawHalfSin * PitchHalfSin * RollHalfCos;
        }

        public Eng_Quaternion(double w, Eng_Vector3D V)
        {
            W = w;
            X = V.X;
            Y = V.Y;
            Z = V.Z;
        }

        //methods



        public override string ToString()
        {
            return $"({W}, {X}, {Y}, {Z})";
        }
    }
}
