﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 3D component vector in 4D homogeneous space
    /// </summary>
    public class Eng_Vector4D
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }

        public double W { get; set; }

        //constructor
        public Eng_Vector4D(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
            W = 1;
        }

        public Eng_Vector4D(double x, double y, double z, double w)
        {
            X = x;
            Y = y;
            Z = z;
            W = w;
        }

        //methods
        public double GetMagnitude()
        {
            return Math.Sqrt((X * X) + (Y * Y) + (Z * Z) + (W * W));
        }
        public override string ToString()
        {
            return $"({X}, {Y}, {Z}, {W})";
        }
    }
}
