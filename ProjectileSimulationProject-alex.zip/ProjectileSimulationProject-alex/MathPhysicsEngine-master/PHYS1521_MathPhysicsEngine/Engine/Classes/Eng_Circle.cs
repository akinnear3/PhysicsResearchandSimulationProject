﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a Circle for mathematical calculations.
    /// </summary>
    public class Eng_Circle
    {
        public Eng_Vector2D center { get; private set; }
        public double radius { get; private set; }
        public double mass { get; private set; }
        public Eng_Vector2D  velocity { get; set; }

        public Eng_Circle(Eng_Vector2D Center, double Radius, double Mass)
        {
            center = Center;
            radius = Radius;
            mass = Mass;
        }
        public Eng_Circle(Eng_Vector2D Center, double Radius, double Mass, Eng_Vector2D Velocity)
        {
            center = Center;
            radius = Radius;
            mass = Mass;
            velocity = Velocity;
        }
    }
}
