﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Classes
{
    /// <summary>
    /// This class represents a 3x3  matrix
    /// </summary>
    public class Eng_Matrix3x3
    {
        public double m11 { get; set; }
        public double m12 { get; set; }
        public double m13 { get; set; }
        public double m21 { get; set; }
        public double m22 { get; set; }
        public double m23 { get; set; }
        public double m31 { get; set; }
        public double m32 { get; set; }
        public double m33 { get; set; }

        public Eng_Matrix3x3(double M11, double M12, double M13, double M21, double M22, double M23, double M31, double M32, double M33)
        {
            m11 = M11;
            m12 = M12;
            m13 = M13;
            m21 = M21;
            m22 = M22;
            m23 = M23;
            m31 = M31;
            m32 = M32;
            m33 = M33;
        }
    }
}
