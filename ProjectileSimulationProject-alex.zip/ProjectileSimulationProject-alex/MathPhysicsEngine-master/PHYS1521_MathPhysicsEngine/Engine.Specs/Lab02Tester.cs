﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Classes;
using Xunit;
using Engine;

namespace Engine.Specs
{
    public class Lab02_Tester
    {
        #region Matrix Multiplication
        public static IEnumerable<Object[]> MatrixMultiplicationData()
        {
            // Instructor Data
            yield return new Object[]
            {
                // Test Datais:
                //   Matrix A
                //   Matrix B
                //   Expected = A x B
                new Eng_Matrix4x4(
                    2, 0, 0, 0.5,
                    0, -2, 0, 1.5,
                    0, 0, 3, 2,
                    0, 0, 0, 1),
                new Eng_Matrix4x4(
                    3, 2, -1, 1,
                    0, 2, 3, -1,
                    2, 0, 2, 2,
                    0, 0, 0, 1),
                new Eng_Matrix4x4(
                    6, 4, -2, 2.5,
                    0, -4, -6, 3.5,
                    6, 0, 6, 8,
                    0, 0, 0, 1)
            };
            // Student Data
            yield return new Object[]
           {
                new Eng_Matrix4x4(
                        2, 1, 1, 0,
                        0, 2, 1, 0,
                        1, 0, 2, 0,
                        1, 1, 0, 2),
                    new Eng_Matrix4x4(
                        1, 0, 0, 2,
                        0.5, 1, 0, 2,
                        0, 0.5, 1, 2,
                        0, 0, 0.5, 1),
                    new Eng_Matrix4x4(
                        2.5, 1.5, 1, 8,
                        1, 2.5, 1, 6,
                        1, 1, 2, 6,
                        1.5, 1, 1, 6)
           };
        }


        public static IEnumerable<Object[]> MatrixVectorMultiplicationData()
        {
            // Instructor Data
            yield return new Object[]
            {
                    // Test Data is:
                    //   Matrix M
                    //   Vector V
                    //   Expected = M x V
                    new Eng_Matrix4x4(
                        2, 0, 0, 0.5,
                        0, -2, 0, 1.5,
                        0, 0, 3, 2,
                        0, 0, 0, 1),
                    new Eng_Vector4D(-2, 3, -5, 1),
                    new Eng_Vector4D(-3.5, -4.5, -13, 1)
            };
            // Student Data
            yield return new Object[]
          {
                  new Eng_Matrix4x4(
                          2, 0, 1, 1,
                          1, 1, 0, 2,
                          0.5, 0, 0.5, 3,
                          0, 0, 0, 1),
                  new Eng_Vector4D( 3, 2, 1, 1),
                  new Eng_Vector4D( 8, 7, 5, 1)
          };
        }

        public static IEnumerable<Object[]> TransposeMatrixData()
        {
            // Instructor Data
            yield return new Object[]
            {
                    // Test Data is:
                    //   Matrix M
                    //   Expected = M^T
                    new Eng_Matrix4x4(
                        2, 0, 0, 0.5,
                        0, -2, 0, 1.5,
                        0, 0, 3, 2,
                        0, 0, 0, 1),
                   new Eng_Matrix4x4(
                       2, 0, 0, 0,
                       0, -2, 0, 0,
                       0, 0, 3, 0,
                       0.5, 1.5, 2, 1)
            };
            // Student Data
            yield return new Object[]
          {
                  new Eng_Matrix4x4(
                          1, 2, 3, 4,
                          5, 6, 7, 8,
                          9, 10, 11, 12,
                          13, 14, 15, 16),
                  new Eng_Matrix4x4(
                          1, 5, 9, 13,
                          2, 6, 10, 14,
                          3, 7, 11, 15,
                          4, 8, 12, 16)
          };
        }

        public static IEnumerable<Object[]> InverseMatrixData()
        {
            // Instructor Data
            yield return new Object[]
            {
                    // Test Data is:
                    //   Matrix M
                    //   Expected = M^-1
                    new Eng_Matrix4x4(
                        2, 0, 0, 0.5,
                        0, -2, 0, 1.5,
                        0, 0, 3, 2,
                        0, 0, 0, 1),
                   new Eng_Matrix4x4(
                       0.5, 0, 0, -0.25,
                       0, -0.5, 0, 0.75,
                       0, 0, 0.3333, -0.6667,
                       0, 0, 0, 1)
            };
            // Student Data
            yield return new Object[]
          {
                  new Eng_Matrix4x4(
                          1, 3, 5, 7,
                          2, 8, 0.5, 0,
                          4, 0, 0, 1, 
                          6, 1, 0, 1),
                  new Eng_Matrix4x4(
                        -0.0033, 0.0331, 0.2781, -0.2550,
                        0.0066, -0.0662, -0.2020, 0.1556,
                        -0.0927, 0.2185, 2.1192, -1.4702,
                        0.0132, -0.1325, -1.4669, 1.0199
                        )
          };
        }

        [Theory]
        [MemberData("MatrixMultiplicationData")]
        public void TestMultiplyMatrices4(Eng_Matrix4x4 givenA, Eng_Matrix4x4 givenB, Eng_Matrix4x4 expected)
        {
            //Arrange - get data to do the test
            //This test uses[MemberData]
            // Act - performing the action
            Eng_Matrix4x4 result = Calculator.MultiplyMatrix4x4ByMatrix4x4(givenA, givenB);
            //Assert - did we get back the correct answer
            Assert.Equal(expected.m11, result.m11);
            Assert.Equal(expected.m12, result.m12);
            Assert.Equal(expected.m13, result.m13);
            Assert.Equal(expected.m14, result.m14);

            Assert.Equal(expected.m21, result.m21);
            Assert.Equal(expected.m22, result.m22);
            Assert.Equal(expected.m23, result.m23);
            Assert.Equal(expected.m24, result.m24);

            Assert.Equal(expected.m31, result.m31);
            Assert.Equal(expected.m32, result.m32);
            Assert.Equal(expected.m33, result.m33);
            Assert.Equal(expected.m34, result.m34);

            Assert.Equal(expected.m41, result.m41);
            Assert.Equal(expected.m42, result.m42);
            Assert.Equal(expected.m43, result.m43);
            Assert.Equal(expected.m44, result.m44);

        }

        [Theory]
        [MemberData("MatrixVectorMultiplicationData")]
        public void TestMultiplyVector4ByMatrix(Eng_Matrix4x4 givenM, Eng_Vector4D givenV, Eng_Vector4D expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Vector4D result = Calculator.MultiplyVectorBy4x4Matrix(givenV, givenM);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.W, result.W);
            Assert.Equal(expected.X, result.X);
            Assert.Equal(expected.Y, result.Y);
            Assert.Equal(expected.Z, result.Z);
        }

        [Theory]
        [MemberData("TransposeMatrixData")]
        public void TestTranposeMatrix(Eng_Matrix4x4 given, Eng_Matrix4x4 expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Matrix4x4 result = Calculator.TransposeA4x4Matrix(given);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.m11, result.m11);
            Assert.Equal(expected.m12, result.m12);
            Assert.Equal(expected.m13, result.m13);
            Assert.Equal(expected.m14, result.m14);

            Assert.Equal(expected.m21, result.m21);
            Assert.Equal(expected.m22, result.m22);
            Assert.Equal(expected.m23, result.m23);
            Assert.Equal(expected.m24, result.m24);

            Assert.Equal(expected.m31, result.m31);
            Assert.Equal(expected.m32, result.m32);
            Assert.Equal(expected.m33, result.m33);
            Assert.Equal(expected.m34, result.m34);

            Assert.Equal(expected.m41, result.m41);
            Assert.Equal(expected.m42, result.m42);
            Assert.Equal(expected.m43, result.m43);
            Assert.Equal(expected.m44, result.m44);
        }

        [Theory]
        // Instructor Data
        [InlineData(2, 0, 0, 0.5, 0, -2, 0, 1.5, 0, 0, 3, 2, 0, 0, 0, 1, -12)]
        // Student Data
        [InlineData(1, 3, 5, 7, 2, 8, 0.5, 0, 4, 0, 0, 1, 6, 1, 0, 1, -151)]
        public void TestDeterminant4(
            double m11, double m12, double m13, double m14,
            double m21, double m22, double m23, double m24,
            double m31, double m32, double m33, double m34,
            double m41, double m42, double m43, double m44,
            double expected)
        {
            // Arrange - get data to do the test
            Eng_Matrix4x4 given = new Eng_Matrix4x4(m11, m12, m13, m14, m21, m22, m23, m24, m31, m32, m33, m34, m41, m42, m43, m44);
            // Act - performing the action
            double result = Calculator.DeterminantOf4x4Matrix(given);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, result);
        }

        [Theory]
        [MemberData("InverseMatrixData")]
        public void TestInverse4(Eng_Matrix4x4 given, Eng_Matrix4x4 expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Matrix4x4 result = Calculator.InverseOf4x4Matrix(given);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.m11, Math.Round(result.m11, 4));
            Assert.Equal(expected.m12, Math.Round(result.m12, 4));
            Assert.Equal(expected.m13, Math.Round(result.m13, 4));
            Assert.Equal(expected.m14, Math.Round(result.m14, 4));

            Assert.Equal(expected.m21, Math.Round(result.m21, 4));
            Assert.Equal(expected.m22, Math.Round(result.m22, 4));
            Assert.Equal(expected.m23, Math.Round(result.m23, 4));
            Assert.Equal(expected.m24, Math.Round(result.m24, 4));//fail

            Assert.Equal(expected.m31, Math.Round(result.m31, 4));//fail
            Assert.Equal(expected.m32, Math.Round(result.m32, 4));//fail
            Assert.Equal(expected.m33, Math.Round(result.m33, 4));//fail
            Assert.Equal(expected.m34, Math.Round(result.m34, 4));//fail

            Assert.Equal(expected.m41, Math.Round(result.m41, 4));//fail
            Assert.Equal(expected.m42, Math.Round(result.m42, 4));//fail
            Assert.Equal(expected.m43, Math.Round(result.m43, 4));//fail
            Assert.Equal(expected.m44, Math.Round(result.m44, 4));//fail
        }
        #endregion

        #region 2D Rotation
        [Theory]
        // Instructor Data
        [InlineData(3, -1, -4, 5, 2, 3, 25, 3.1415, 0.3615, -5.7383, 2.8411, 0.5448, 3.5642)]
        // Student Data
        [InlineData(1, 1, 2, 1, 1, 3, 45, 0, 1.4142, 0.7071, 2.1213, -1.4142, 2.8284)]
        public void TestRotation2D(
            double x1, double y1, double x2, double y2, double x3, double y3, double degrees,
            double expectedx1, double expectedy1,
            double expectedx2, double expectedy2,
            double expectedx3, double expectedy3)
        {
            // Arrange - get data to do the test
            Eng_Vector3D PointA = new Eng_Vector3D(x1, y1, 1);
            Eng_Vector3D PointB = new Eng_Vector3D(x2, y2, 1);
            Eng_Vector3D PointC = new Eng_Vector3D(x3, y3, 1);
            double cos = Math.Cos(Calculator.DegreeToRadians(degrees));
            double sin = Math.Sin(Calculator.DegreeToRadians(degrees));
            Eng_Matrix3x3 EulerAngle = new Eng_Matrix3x3(cos, -sin, 0, sin, cos, 0, 0, 0, 1);
            // Act - performing the action
            Eng_Vector3D resultA1 = Calculator.Point2DRotationByAngle(PointA, degrees);
            Eng_Vector3D resultB1 = Calculator.Point2DRotationByAngle(PointB, degrees);
            Eng_Vector3D resultC1 = Calculator.Point2DRotationByAngle(PointC, degrees);

            Eng_Vector3D resultA2 = Calculator.Point2DRotationByMatrix(PointA, EulerAngle);
            Eng_Vector3D resultB2 = Calculator.Point2DRotationByMatrix(PointB, EulerAngle);
            Eng_Vector3D resultC2 = Calculator.Point2DRotationByMatrix(PointC, EulerAngle);
            // Assert - did we get back the correct answer
            Assert.Equal(expectedx1, Math.Round(resultA1.X, 4));//round answers
            Assert.Equal(expectedx1, Math.Round(resultA2.X, 4));
            Assert.Equal(expectedx2, Math.Round(resultB1.X, 4));
            Assert.Equal(expectedx2, Math.Round(resultB2.X, 4));
            Assert.Equal(expectedx3, Math.Round(resultC1.X, 4));
            Assert.Equal(expectedx3, Math.Round(resultC2.X, 4));

            Assert.Equal(expectedy1, Math.Round(resultA1.Y, 4));
            Assert.Equal(expectedy1, Math.Round(resultA2.Y, 4));
            Assert.Equal(expectedy2, Math.Round(resultB1.Y, 4));
            Assert.Equal(expectedy2, Math.Round(resultB2.Y, 4));
            Assert.Equal(expectedy3, Math.Round(resultC1.Y, 4));
            Assert.Equal(expectedy3, Math.Round(resultC2.Y, 4));
        }
        #endregion

        #region 3D Rotation
        public static IEnumerable<Object[]> QuaternionToMatrixData()
        {
            // Instructor Data
            yield return new Object[]
            {
                // Test Data is:
                //   Quaternion Q
                //   Expected = M
                new Eng_Quaternion(15, 10, 5),
                new Eng_Matrix4x4(
                    0.9662, -0.2432, 0.0858, 0,
                    0.2549, 0.9513, -0.1736, 0,
                    -0.0394, 0.1897, 0.9811, 0,
                    0, 0, 0, 1)

            };
            // Student Data
            yield return new Object[]
            {
                new Eng_Quaternion( 3, 2, 1, 4),
                new Eng_Matrix4x4(
                        -33, -20, 22, 0,
                        28, -39, -4, 0,
                        10, 20, -9, 0,
                        0, 0, 0, 1)
            };
        }

        public static IEnumerable<Object[]> Rotate3DData()
        {

            // Instructor Data
            yield return new Object[]
            {
                // Test Data is:
                //   Vector V
                //   Quaternion V
                //   Expected = Q x V, converting Q to Matrix R,
                //            = R x V 
                new Eng_Vector4D(-2, 5, 3, 1),
                new Eng_Quaternion(15, 10, 5),
                new Eng_Vector4D(-2.8909, 3.7255, 3.9703, 1)

            };
            // Student Data
            yield return new Object[]
            {
                new Eng_Vector4D( -2, 3, 4, 1),
                new Eng_Quaternion( 2, 4, 6),
                new Eng_Vector4D( -1.6535, 2.6422, 4.3914, 1)
            };
        }

        [Theory]
        // Instructor Data
        [InlineData(15, 10, 5, 0.987228288176272, 0.0919996771632968, 0.0317163728481948, 0.126136585175556)]
        // Student Data
        [InlineData(2, 4, 6, 0.99790107, 0.035759192, 0.051687863, 0.015591651)]
        public void TestQuaternion(
            double bank, double attitude, double heading,
            double expectedQw, double expectedQx, double expectedQy, double expectedQz)
        {
            // Arrange - get data to do the test
            // Act - performing the action
            Eng_Quaternion result = new Eng_Quaternion(bank, attitude, heading);
            // Assert - did we get back the correct answer
            Assert.Equal(Math.Round(expectedQw, 8), Math.Round(result.W, 8));//My data fails
            Assert.Equal(Math.Round(expectedQx, 8), Math.Round(result.X, 8));
            Assert.Equal(Math.Round(expectedQy, 8), Math.Round(result.Y, 8));
            Assert.Equal(Math.Round(expectedQz, 8), Math.Round(result.Z, 8));
        }

        [Theory]
        [MemberData("QuaternionToMatrixData")]
        public void TestQuaternionToMatrix(Eng_Quaternion q, Eng_Matrix4x4 expected)
        {
            // Arrange - get data to do the test
            // This method uses MemberData
            // Act - performing the action
            Eng_Matrix4x4 result = Calculator.QuaternionToMatrix(q);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.m11, Math.Round(result.m11, 4));
            Assert.Equal(expected.m12, Math.Round(result.m12, 4));
            Assert.Equal(expected.m13, Math.Round(result.m13, 4));
            Assert.Equal(expected.m14, Math.Round(result.m14, 4));

            Assert.Equal(expected.m21, Math.Round(result.m21, 4));
            Assert.Equal(expected.m22, Math.Round(result.m22, 4));
            Assert.Equal(expected.m23, Math.Round(result.m23, 4));
            Assert.Equal(expected.m24, Math.Round(result.m24, 4));

            Assert.Equal(expected.m31, Math.Round(result.m31, 4));
            Assert.Equal(expected.m32, Math.Round(result.m32, 4));
            Assert.Equal(expected.m33, Math.Round(result.m33, 4));
            Assert.Equal(expected.m34, Math.Round(result.m34, 4));

            Assert.Equal(expected.m41, Math.Round(result.m41, 4));
            Assert.Equal(expected.m42, Math.Round(result.m42, 4));
            Assert.Equal(expected.m43, Math.Round(result.m43, 4));
            Assert.Equal(expected.m44, Math.Round(result.m44, 4));
        }

        [Theory]
        [MemberData("Rotate3DData")]
        public void TestRotate3D(Eng_Vector4D v, Eng_Quaternion q, Eng_Vector4D expected)
        {
            // Arrange - get data to do the test
            // This method uses MemberData
            // Act - performing the action
            Eng_Vector4D result = Calculator.RotateVectorByQuaternion(v, q);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.X, Math.Round(result.X, 4));//my data failed
            Assert.Equal(expected.Y, Math.Round(result.Y, 4));
            Assert.Equal(expected.Z, Math.Round(result.Z, 4));
            Assert.Equal(expected.W, Math.Round(result.W, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(0.987228288176272, 0.0919996771632968, 0.0317163728481948, 0.126136585175556, 15, 10, 5)]
        // Student Data
        [InlineData(0.99790107, 0.035759192, 0.051687863, 0.015591651, 2, 4, 6)]
        public void TestQuaterionToEuler(double qW, double qX, double qY, double qZ,
            double expectedRoll, double expectedPitch, double expectedYaw)
        {
            // Arrange - get data to do the test
            Eng_Quaternion given = new Eng_Quaternion(qW, qX, qY, qZ);
            // Act - performing the action
            Tuple<double, double, double> result = Calculator.QuaternionToEuler(given);
            // Assert - did we get back the correct answer
            Assert.Equal(expectedRoll, Math.Round(result.Item1, 4));
            Assert.Equal(expectedPitch, Math.Round(result.Item2, 4));
            Assert.Equal(expectedYaw, Math.Round(result.Item3, 4));
        }
        #endregion
    }
}
