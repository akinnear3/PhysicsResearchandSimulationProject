﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Engine.Classes;
using Xunit;

namespace Engine.Specs
{
    public class Lab01_Tester
    {
        #region My tests

        #region trig
        //Test for Part 1
        [Theory]
        // Instructor Data
        [InlineData(25, 6, 5.4378, 2.5357)]
        // Student Data
        [InlineData(53, 5, 3.0091, 3.9932)]
        public void TestCalculateAdjacentOpposite(double degrees, double hypotenuse, double adjacent, double opposite)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            Tuple<double, double> results = Calculator.SolveWithHypAndDegree(hypotenuse, degrees);
            // Assert - did we get back the correct answer
            Assert.Equal(adjacent, Math.Round(results.Item1, 4));
            Assert.Equal(opposite, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(25, 6, 12.867, 14.1972)]
        // Student Data
        [InlineData(53, 4, 3.0142, 5.0085)]
        public void TestCalculateAdjacentHypotenuse(double degrees, double opposite, double adjacent, double hypotenuse)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            Tuple<double, double> results = Calculator.SolveWithOppAndDegree(opposite, degrees);
            // Assert - did we get back the correct answer
            Assert.Equal(adjacent, Math.Round(results.Item1, 4));
            Assert.Equal(hypotenuse, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(25, 6, 2.7978, 6.6203)]
        // Student Data
        [InlineData(53, 3, 3.9811, 4.9849)]
        public void TestCalculateOppositeHypotenuse(double degrees, double adjacent, double opposite, double hypotenuse)
        {

            // Arrange - get data to do the test

            // Act - performing the action
            Tuple<double, double> results = Calculator.SolveWithAdjAndDegree(adjacent, degrees);
            // Assert - did we get back the correct answer
            Assert.Equal(opposite, Math.Round(results.Item1, 4));
            Assert.Equal(hypotenuse, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 5, 53.1301)]
        // Student Data
        [InlineData(12, 3, 12.3693, 14.0362)]
        public void TestCalculateHypotenuseTheta(double adjacent, double opposite, double hypotenuse, double degrees)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            Tuple<double, double> results = Calculator.SolveWithOppAndAdj(opposite, adjacent);
            // Assert - did we get back the correct answer
            Assert.Equal(hypotenuse, Math.Round(results.Item1, 4));
            Assert.Equal(degrees, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 2.6458, 48.5904)]
        // Student Data
        [InlineData(4, 5, 3, 53.1301)]
        public void TestCalculateAdjacentTheta(double opposite, double hypotenuse, double adjacent, double degrees)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            Tuple<double, double> results = Calculator.SolveWithOppAndHyp(opposite, hypotenuse);
            // Assert - did we get back the correct answer
            Assert.Equal(adjacent, Math.Round(results.Item1, 4));
            Assert.Equal(degrees, Math.Round(results.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 2.6458, 41.4096)]
        // Student Data
        [InlineData(3, 5, 4, 53.1301)]
        public void TestCalculateOppositeTheta(double adjacent, double hypotenuse, double opposite, double degrees)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            Tuple<double, double> results = Calculator.SolveWithAdjAndHyp(adjacent, hypotenuse);
            // Assert - did we get back the correct answer
            Assert.Equal(opposite, Math.Round(results.Item1, 4));
            Assert.Equal(degrees, Math.Round(results.Item2, 4));
        }

        #endregion

        #region 2Dvectors
        /*
         * 
         * 2D vector tests
         * 
         */
        // Static method to set up Object-based test data
        public static IEnumerable<Object[]> AddVector2DData()
        {
            // Instructor Data
            yield return new Object[]
            {
        new Eng_Vector2D(3, 4),
        new Eng_Vector2D(6, 9),
        new Eng_Vector2D(9, 13)
            };
            // Student Data
            yield return new Object[]
             {
        new Eng_Vector2D(3, 3),
        new Eng_Vector2D(4, 4),
        new Eng_Vector2D(7, 7)
             };
            yield return new Object[]
            {
        new Eng_Vector2D(3, 4),
        new Eng_Vector2D(-6, -9),
        new Eng_Vector2D(-3, -5)
            };
        }

        public static IEnumerable<Object[]> NormalizeVector2DData()
        {
            // Instructor Data
            yield return new Object[]
            {
        new Eng_Vector2D(3, 4),
        new Eng_Vector2D(0.6, 0.8)
            };
            // Student Data
            yield return new Object[]
 {
        new Eng_Vector2D(3, 3),
        new Eng_Vector2D(0.7071, 0.7071)

 };
            yield return new Object[]
            {
        new Eng_Vector2D(-6, -9),
        new Eng_Vector2D(-0.5547, -0.8321)
            };
        }

        [Theory]
        [MemberData("AddVector2DData")]
        public void TestAddVector(Eng_Vector2D givenA, Eng_Vector2D givenB, Eng_Vector2D expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Vector2D results = Calculator.AddingVectors(givenA, givenB);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.X, Math.Round(results.X, 4));
            Assert.Equal(expected.Y, Math.Round(results.Y, 4));
        }

        [Theory]
        [MemberData("NormalizeVector2DData")]
        public void TestNormailze(Eng_Vector2D givenA, Eng_Vector2D expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Vector2D result = Calculator.normalize2DVector(givenA);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.X, Math.Round(result.X, 4));
            Assert.Equal(expected.Y, Math.Round(result.Y, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 6, 9, 54)]
        // Student Data
        [InlineData(5, 3, 4, 2, 26)]
        public void TestDotProduct(double givenAx, double givenAy, double givenBx, double givenBy, double expected)
        {
            // Arrange - get data to do the test
            Eng_Vector2D getA = new Eng_Vector2D(givenAx, givenAy);
            Eng_Vector2D getB = new Eng_Vector2D(givenBx, givenBy);
            // Act - performing the action
            double result = Calculator.DotProduct2DVectors(getA, getB);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, Math.Round(result, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 6, 9, 3.1798)]
        // Student Data
        [InlineData(5, 3, 4, 2, 4.3987)]
        public void TestAngleBetweenVectors(double givenAx, double givenAy, double givenBx, double givenBy, double expected)
        {
            // Arrange - get data to do the test
            Eng_Vector2D getA = new Eng_Vector2D(givenAx, givenAy);
            Eng_Vector2D getB = new Eng_Vector2D(givenBx, givenBy);
            // Act - performing the action
            double result = Calculator.AngleBetween2DVectors(getA, getB);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, Math.Round(result, 4));
        }
        #endregion

        #region 3Dvectors
        /*
         * 
         * 3D vector tests
         * 
         */

        // Static method to set up Object-based test data
        public static IEnumerable<Object[]> AddVector3DData()
        {
            // Instructor Data
            yield return new Object[]
            {
        new Eng_Vector3D(3, 4, 5),
        new Eng_Vector3D(6, 9, -2),
        new Eng_Vector3D(9, 13, 3)
            };
            // Student Data
            yield return new Object[]
             {
        new Eng_Vector3D(12, 10, 8),
        new Eng_Vector3D(-3, -6, -9),
        new Eng_Vector3D(9, 4, -1)
             };
        }

        public static IEnumerable<Object[]> NormalizeVector3DData()
        {
            // Instructor Data
            yield return new Object[]
            {
       new Eng_Vector3D(3, 4, 5),
       new Eng_Vector3D(0.4243, 0.5657, 0.7071)
            };
            // Student Data
            yield return new Object[]
            {
       new Eng_Vector3D(2, -2, 8),
       new Eng_Vector3D(0.2357, -0.2357, 0.9428)
            };
        }

        public static IEnumerable<Object[]> CrossProductData()
        {
            // Instructor Data
            yield return new Object[]
            {
        new Eng_Vector3D(3, 4, 5),
        new Eng_Vector3D(6, 9, -1),
        new Eng_Vector3D(-49, 33, 3)
            };
            // Student Data
            yield return new Object[]
            {
        new Eng_Vector3D(2, 4, 8),
        new Eng_Vector3D(-3, 6, -9),
        new Eng_Vector3D(-84, -6, 24)
            };
        }

        public static IEnumerable<Object[]> SurfaceNormalData()
        {
            // Instructor Data
            yield return new Object[]
            {
        new Eng_Vector3D(3, 4, 5),
        new Eng_Vector3D(6, 9, -1),
        new Eng_Vector3D(-0.8284, 0.5579, 0.0507)
            };
            // Student Data
            yield return new Object[]
            {
        new Eng_Vector3D(2, 4, 8),
        new Eng_Vector3D(-3, 6, -9),
        new Eng_Vector3D(-0.9593, -0.0685, 0.2741)
            };
        }

        [Theory]
        [MemberData("AddVector3DData")]
        public void TestAddVector(Eng_Vector3D givenA, Eng_Vector3D givenB, Eng_Vector3D expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Vector3D result = Calculator.Add3DVector(givenA, givenB);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.X, Math.Round(result.X, 4));
            Assert.Equal(expected.Y, Math.Round(result.Y, 4));
            Assert.Equal(expected.Z, Math.Round(result.Z, 4));
        }

        [Theory]
        [MemberData("NormalizeVector3DData")]
        public void TestNormailze(Eng_Vector3D givenA, Eng_Vector3D expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Vector3D result = Calculator.Normalize3DVector(givenA);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.X, Math.Round(result.X, 4));
            Assert.Equal(expected.Y, Math.Round(result.Y, 4));
            Assert.Equal(expected.Z, Math.Round(result.Z, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 5, 6, 9, -1, 49)]
        // Student Data
        [InlineData(7, 5, 3, 6, 4, 2, 68)]
        public void TestDotProduct3D(double givenAx, double givenAy, double givenAz, double givenBx, double givenBy, double givenBz, double expected)
        {
            // Arrange - get data to do the test
            Eng_Vector3D getA = new Eng_Vector3D(givenAx, givenAy, givenAz);
            Eng_Vector3D getB = new Eng_Vector3D(givenBx, givenBy, givenBz);
            // Act - performing the action
            double result = Calculator.DotProduct3DVector(getA, getB);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, Math.Round(result, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, 4, 5, 6, 9, -1, 50.3627)]
        // Student Data
        [InlineData(7, 5, 3, 6, 4, 2, 4.1207)]
        public void TestAngleBetweenVectors3D(double givenAx, double givenAy, double givenAz, double givenBx, double givenBy, double givenBz, double expected)
        {
            // Arrange - get data to do the test
            Eng_Vector3D getA = new Eng_Vector3D(givenAx, givenAy, givenAz);
            Eng_Vector3D getB = new Eng_Vector3D(givenBx, givenBy, givenBz);
            // Act - performing the action
            double result = Calculator.Angle3DVector(getA, getB);
            // Assert - did we get back the correct answer
            Assert.Equal(expected, Math.Round(result, 4));
        }

        [Theory]
        [MemberData("CrossProductData")]
        public void TestCrossProduct(Eng_Vector3D givenA, Eng_Vector3D givenB, Eng_Vector3D expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Vector3D result = Calculator.CrossProduct3DVector(givenA, givenB);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.X, Math.Round(result.X, 4));
            Assert.Equal(expected.Y, Math.Round(result.Y, 4));
            Assert.Equal(expected.Z, Math.Round(result.Z, 4));
        }

        [Theory]
        [MemberData("SurfaceNormalData")]
        public void TestSurfaceNormal(Eng_Vector3D givenA, Eng_Vector3D givenB, Eng_Vector3D expected)
        {
            // Arrange - get data to do the test
            // This test uses [MemberData]
            // Act - performing the action
            Eng_Vector3D result = Calculator.SurfaceNormal3DVector(givenA, givenB);
            // Assert - did we get back the correct answer
            Assert.Equal(expected.X, Math.Round(result.X, 4));
            Assert.Equal(expected.Y, Math.Round(result.Y, 4));
            Assert.Equal(expected.Z, Math.Round(result.Z, 4));
        }

        #endregion

        #endregion
    }
}
