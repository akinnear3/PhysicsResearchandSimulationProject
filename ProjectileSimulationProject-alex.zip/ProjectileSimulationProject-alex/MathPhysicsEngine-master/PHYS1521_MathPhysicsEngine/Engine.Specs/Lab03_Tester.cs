﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Classes;
using Xunit;

namespace Engine.Specs
{
    public class Lab03_Tester
    {
        #region Linear Motion
        [Theory]
        // Instructor Data
        [InlineData(3, -2, 0, -9.81, 2.5, 3, -26.525, 7.5, -35.6562)]
        // Student Data
        [InlineData(1,1, 0,-3, 5, 1,-14, 5,-32.5)]
        public static void TestCalculateVelcityDisplacement(
            double vIx, double vIy, double gX, double gY, double t,
            double vFx, double vFy, double dX, double dY)
        {
            // Arrange - get data to do the test
            Eng_Vector2D v = new Eng_Vector2D(vIx, vIy);
            Eng_Vector2D g = new Eng_Vector2D(gX, gY);
            // Act - performing the action
            Tuple<Eng_Vector2D, Eng_Vector2D> result = Calculator.getFinalVelocityandDisplacement(g, t, v);
            // Assert - did we get back the correct answers
            Assert.Equal(vFx, Math.Round(result.Item1.X, 4));
            Assert.Equal(vFy, Math.Round(result.Item1.Y, 4));
            Assert.Equal(dX, Math.Round(result.Item2.X, 4));
            Assert.Equal(dY, Math.Round(result.Item2.Y, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(2.5, 5, 15, -9.81, 4.4109, 15.0024, 1.7711)]
        // Student Data
        [InlineData(30, 30, 30, -3.3, 280.0172, 64.0909, 10.7779)]
        public static void TestCalculateProjectile(
            double vI, double degrees, double h, double g,
            double distance, double maxHeight, double t)
        {
            // Arrange - get data to do the test
            Eng_Vector2D VI = new Eng_Vector2D(vI * Math.Cos(Calculator.DegreeToRadians(degrees)), vI * Math.Sin(Calculator.DegreeToRadians(degrees)));
            // Act - performing the action
            Tuple<double, double, double> result1 = Calculator.getHorizontalDisplacementMaxHeightTime(g, h, VI);
            Tuple<double, double, double> result2 = Calculator.getHorizontalDisplacementMaxHeightTime(g, h, vI, degrees);
            // Assert - did we get back the correct answers
            Assert.Equal(distance, Math.Round(result1.Item1, 4));
            Assert.Equal(maxHeight, Math.Round(result1.Item2, 4));
            Assert.Equal(t, Math.Round(result1.Item3, 4));
            Assert.Equal(distance, Math.Round(result2.Item1, 4));
            Assert.Equal(maxHeight, Math.Round(result2.Item2, 4));
            Assert.Equal(t, Math.Round(result2.Item3, 4));
        }
        #endregion

        #region Rotational Motion
        [Theory]
        // Instructor Data
        [InlineData(3200, 0.25, 335.1032, 28073.5414)]
        // Student Data
        [InlineData(3000, 0.5, 314.1593, 49348.0220)]
        public void TestRotationalMotion1(
            double rpm, double radius, double omega, double aT_Expected)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            Tuple<double, double> result = Calculator.getAngularVelocityAndAngularAcceleration(rpm, radius);
            // Assert - did we get back the correct answers
            Assert.Equal(omega, Math.Round(result.Item1, 4));
            Assert.Equal(aT_Expected, Math.Round(result.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(0.25, 0.4, 2, 0.625, 35.8099, 0.3125, 0.1562, 0.125)]
        //student data
        [InlineData(5, 3, 0.1, 1.6667, 95.4930, 16.6667, 166.6667, 50)]
        public static void TestRotationalMotion2(
            double arc, double radius, double t,
            double thetaR, double thetaD, double omega, double alpha, double vT)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            var result = Calculator.getAngle_AngularV_AngularA_TangentalV(arc, radius, t);
            // Assert - did we get back the correct answers
            Assert.Equal(thetaR, Math.Round(result.Item1, 4));
            Assert.Equal(thetaD, Math.Round(result.Item2, 4));
            Assert.Equal(omega, Math.Round(result.Item3, 4));
            Assert.Equal(alpha, Math.Round(result.Item4, 4));
            Assert.Equal(vT, Math.Round(result.Item5, 4));
   
        }

        [Theory]
        // Instructor Data
        [InlineData(0.5, 0.25, 0.35, 0.125, 0.175)]
        // Student Data
        [InlineData(299, 1, 1.5, 299, 448.5)]
        public static void TestRotaionalMotion3(
            double omega, double aRadius, double bRadius,
            double vTa, double vTb)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            var result = Calculator.getTangentalVelocityOfTwoObjects(omega, aRadius, bRadius);
            // Assert - did we get back the correct answers
            Assert.Equal(vTa, Math.Round(result.Item1, 4));
            Assert.Equal(vTb, Math.Round(result.Item2, 4));
        }
        #endregion
        
        #region Forces
        [Theory]
        // Instructor Data
        [InlineData(0, -9.81, 100, 500, 10, 0.15, 0, 358.2775, 0, 3.5828, 0, 1.5, 5.3742, 0, 4.0306, 0)]// non-incline
        [InlineData(0, -9.81, 100, 500, 0, 0.15, 10, 184.7367, 0, 1.8474, 0, 1.5, 2.7711, 0, 2.0783, 0)]// incline
        // Student Data (two sets of data)
        [InlineData(0,-3, 2, 50,1, 0.97, 0, 45.0188,0, 22.5094,0, 3, 67.5282,0, 101.2924,0)]    // non-incline
        [InlineData(0,-10, 100, 1000,0, 0.99, 20, 0,0, 0,0, 3, 0,0, 0,0)]    // incline
        public static void TestCalculateNetForce(
            double gX, double gY, double mass, double force, double forceAngle,
            double mu, double inclineDegrees, double netFx, double netFy,
            double aX, double aY, double t, double vFx, double vFy,
            double dX, double dY)
        {
            // Arrange - get data to do the test
            Eng_Vector2D gravity = new Eng_Vector2D(gX, gY);
            Eng_Vector2D externalForce = new Eng_Vector2D(force * Math.Cos(Calculator.DegreeToRadians(forceAngle)), force * Math.Sin(Calculator.DegreeToRadians(forceAngle)));
            // Act - performing the action
            var result = Calculator.getNetForceAndAcceleration(externalForce, inclineDegrees, mass, gravity, mu, t);
            // Assert - did we get back the correct answers
            Assert.Equal(netFx, Math.Round(result.Item1.X, 4));
            Assert.Equal(netFy, Math.Round(result.Item1.Y, 4));
            Assert.Equal(aX, Math.Round(result.Item2.X, 4));
            Assert.Equal(aY, Math.Round(result.Item2.Y, 4));
            Assert.Equal(dX, Math.Round(result.Item3.X, 4));
            Assert.Equal(dY, Math.Round(result.Item3.Y, 4));
            Assert.Equal(vFx, Math.Round(result.Item4.X, 4));
            Assert.Equal(vFy, Math.Round(result.Item4.Y, 4));
        }
        #endregion

        #region Gravitational Forces
        [Theory]
        // Instructor Data
        [InlineData(450000, 9500000000, 25000, 0.0004564332)]
        // Student Data
        [InlineData(55e3, 45e4, 34e4, 1.428691609e-11)]
        public static void TestCalculateGravitationalForce(
            double mass1, double mass2, double centersDistance,
            double expected)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            var result = Calculator.getForceOfGravity(mass1, mass2, centersDistance);
            // Assert - did we get back the correct answer
            Assert.Equal(Math.Round(expected, 10), Math.Round(result, 10));
        }

        [Theory]
        // Instructor Data
        [InlineData(3.5e24, 5e6, -9.3422)]
        // Student Data
        [InlineData(45e16, 34e4, -2.597621107e-4)]
        public static void TestCalculateGravity(double mass, double radius, double expected)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            var result = Calculator.getSurfaceAttraction(mass, radius);
            // Assert - did we get back the correct answer
            Assert.Equal(Math.Round(expected, 4), Math.Round(result, 4));
        }
        #endregion

        #region Springs
        [Theory]
        // Instructor Data
        [InlineData(0.3, 0.75, -9.81, 24.525)]
        // Student Data
        [InlineData(0.1, 12, -10, 1200)]
        public static void TestCalculateSpringConstant(
            double stretchedLength, double mass, double gravity, double expected)
        {
            // Arrange - get data to do the test
            double force = mass * gravity;
            // Act - performing the action
            var result = Calculator.getSpringConstant(force, stretchedLength);
            // Assert - did we get back the correct answer
             Assert.Equal(Math.Round(expected, 3), Math.Round(result, 3));
        }

        [Theory]
        // Instructor Data
        [InlineData(24.525, 0.75, 0.3, 0.9101, 1.7155)]
        // Student Data
        [InlineData(1200, 12, 0.1, 1.591549431, 1)]
        public static void TestCalculateSpringFreqVelocity(
            double k, double mass, double stretchedLength, double expectedFreq, double expectedVelocity)
        {
            // Arrange - get data to do the test

            // Act - performing the action
            var result = Calculator.getVelocityAndFrequencyAtEquilibreum(mass, k, stretchedLength);
            // Assert - did we get back the correct answers
            Assert.Equal(Math.Round(expectedFreq, 4), Math.Round(result.Item2, 4));
            Assert.Equal(Math.Round(expectedVelocity, 4), Math.Round(result.Item1, 4));
        }
        #endregion

        #region Impulse and Momentum
        [Theory]
        // Instructor Data
        [InlineData(5, 1025, 105, 5125, 48.8095)]
        // Student Data
        [InlineData(5, 10, 2, 50, 25)]
        public static void TestCalculateMomentum(
            double vI, double mass, double brakingForce, double p, double t)
        {
            // Arrange - get data to do the test
            Eng_Vector2D VI = new Eng_Vector2D(vI, 0);
            // Act - performing the action
            var result = Calculator.getMomentumAndStopingTime(VI, mass, brakingForce);
            // Assert - did we get back the correct answers
            Assert.Equal(Math.Round(p, 4), Math.Round(result.Item1.X, 4));
            Assert.Equal(Math.Round(t, 4), Math.Round(result.Item2, 4));
        }

        [Theory]
        // Instructor Data
        [InlineData(3, -2, 1.5, 10, 1, 2, 4, -1, 2.5, 5, -2, -1, -1, 0, 2, 3)]
        // Student Data
        [InlineData(1,1, 1, 4, 2,3, 3,3, 2,8,-2,1,-2,-1,0,3)]
        public static void TestCircleCollision(
            double aX, double aY, double aR, double aMass, double aViX, double aViY,
            double bX, double bY, double bR, double bMass, double bViX, double bViY,
            double aVfX, double aVfY, double bVfX, double bVfY)
        {
            // Arrange - get data to do the test
            Eng_Circle a = new Eng_Circle(new Eng_Vector2D(aX, aY), aR, aMass,new Eng_Vector2D(aViX, aViY));
            Eng_Circle b = new Eng_Circle(new Eng_Vector2D(bX, bY), bR, bMass, new Eng_Vector2D(bViX, bViY));
            // Act - performing the action
            var result = Calculator.getFinalVelocitiesofTwoCirclesColliding(a, b);
            // Assert - did we get back the correct answers
            Assert.Equal(Math.Round(aVfX, 4), Math.Round(result.Item1.X, 4));
            Assert.Equal(Math.Round(aVfY, 4), Math.Round(result.Item1.Y, 4));
            Assert.Equal(Math.Round(bVfX, 4), Math.Round(result.Item2.X, 4));//fail
            Assert.Equal(Math.Round(bVfY, 4), Math.Round(result.Item2.Y, 4));//fail
        }

        [Theory]
        // Instructor Data
        [InlineData(3, -2, 4, 1.5, 10, 1, 2, 2, 4, -1, -2, 2.5, 5, -2, -1, 2, 0.8947, 1.8947, 2.6316, -1.7895, -0.7895, 0.7368)]
        // Student Data
        [InlineData(3,5,6,8,0.9,0.1,1.04,2, 7,2,-6,5,0.84,0.2,-2.5,1.1, 0.598641094,0.66601918,0.504076719, -0.334258315,-2.099306264,2.702774944)]
        public static void TestSphereCollision(
            double aX, double aY, double aZ, double aR, double aMass, double aViX, double aViY, double aViZ,
            double bX, double bY, double bZ, double bR, double bMass, double bViX, double bViY, double bViZ,
            double aVfX, double aVfY, double aVfZ, double bVfX, double bVfY, double bVfZ)
        {
            // Arrange - get data to do the test
            Eng_Sphere a = new Eng_Sphere(new Eng_Vector3D(aX, aY, aZ), aR, aMass, new Eng_Vector3D(aViX, aViY, aViZ));
            Eng_Sphere b = new Eng_Sphere(new Eng_Vector3D(bX, bY, bZ), bR, bMass, new Eng_Vector3D(bViX, bViY, bViZ));
            // Act - performing the action
            var result = Calculator.getFinalVelocitiesofTwoSpheresColiding(a, b);
            // Assert - did we get back the correct answers
            Assert.Equal(Math.Round(aVfX, 4), Math.Round(result.Item1.X, 4));
            Assert.Equal(Math.Round(aVfY, 4), Math.Round(result.Item1.Y, 4));
            Assert.Equal(Math.Round(aVfZ, 4), Math.Round(result.Item1.Z, 4));
            Assert.Equal(Math.Round(bVfX, 4), Math.Round(result.Item2.X, 4));
            Assert.Equal(Math.Round(bVfY, 4), Math.Round(result.Item2.Y, 4));
            Assert.Equal(Math.Round(bVfZ, 4), Math.Round(result.Item2.Z, 4));
        }
        #endregion
    }
}

