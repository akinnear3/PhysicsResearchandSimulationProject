# TODO List

## Introduction
This project is far from perfect and is only in its infancy. To that end there are a number of enhancements that should be made. These include, but are not limited to:

* Eng_Particle class
* Eng_Body class (for rigid bodies only)
* Collision Detection
  * Bounding Box
  * Bounding Cube
  * Bounding Circle
  * Bounding Sphere
* World creation
